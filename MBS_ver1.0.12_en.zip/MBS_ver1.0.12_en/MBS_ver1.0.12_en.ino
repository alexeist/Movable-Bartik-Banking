#include <WiFi.h>
#include <WebServer.h>
#include <SPIFFS.h>
#include <ArduinoJson.h>
#include <time.h>

const char* ver = "1.0.12_en";

// ====================== CONFIGURATION ======================
String ssid = String("InfoBoard_") + ver;
const char* password = "";

WebServer server(80);

// ====================== STRUCTURE ======================
struct Advertisement {
  uint32_t id;
  String title;
  String content;
  String category;
  String price;
  String currency;
  uint32_t timestamp;
  String timeString;
};

const int MAX_ADS = 50;
Advertisement ads[MAX_ADS];
int adCount = 0;
uint32_t nextId = 1;

// ====================== HTML ======================
const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MBS InfoBoard</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:Arial,sans-serif;background:#f0f0f0;padding:20px;}
.container{max-width:800px;margin:0 auto;background:white;border-radius:10px;padding:20px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
h1{text-align:center;margin-bottom:10px;color:#333;}
h3{text-align:center;margin-bottom:5px;color:#666;}
.version-info{text-align:center;color:#999;font-size:14px;margin-bottom:15px;font-style:italic;}
.status-bar{background:#f8f9fa;border:1px solid #dee2e6;border-radius:8px;padding:12px 15px;margin-bottom:15px;font-size:14px;color:#333;line-height:1.8;}
.status-bar .param{font-weight:bold;color:#333;}
.status-bar .value{font-weight:normal;color:#555;}
.search-box{margin-bottom:20px;position:relative;}
.search-box input{width:100%;padding:12px 40px 12px 12px;border:1px solid #ddd;border-radius:8px;font-size:16px;}
form{display:flex;flex-direction:column;gap:12px;margin-bottom:25px;}
input,textarea,select{padding:12px;border:1px solid #ddd;border-radius:8px;font-size:15px;}
button{padding:12px;background:#007bff;color:white;border:none;border-radius:8px;cursor:pointer;font-size:16px;}
button:hover{background:#0056b3;}
.ad-card{border:1px solid #ddd;border-radius:8px;padding:15px;margin-bottom:12px;background:#fafafa;}
.ad-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}
.ad-title{font-weight:bold;font-size:18px;}
.ad-category{background:#28a745;color:white;padding:3px 10px;border-radius:12px;font-size:13px;}
.price{font-weight:bold;color:#28a745;font-size:17px;margin:8px 0;}
.delete-btn{background:#dc3545;color:white;border:none;padding:6px 12px;border-radius:5px;cursor:pointer;font-size:13px;}
.delete-btn:hover{background:#c82333;}
.no-ads{text-align:center;color:#666;padding:30px;}
</style>
</head>
<body>
<div class="container">
    <h1>📋 MBS InfoBoard</h1>
    <h3>Movable Bartik Storage</h3>
    <div class="version-info">Version: {{VERSION}}</div>
    
    <div class="status-bar" id="status-bar">
        📊 Memory Status:<br>
        <span class="param">Total:</span> <span class="value" id="mem-total">Loading...</span><br>
        <span class="param">Used:</span> <span class="value" id="mem-used">Loading...</span><br>
        <span class="param">Free:</span> <span class="value" id="mem-free">Loading...</span><br>
        <span class="param">Ads:</span> <span class="value" id="mem-ads">Loading...</span>
    </div>
    
    <div class="search-box">
        <input type="text" id="search-input" placeholder="🔍 Search...">
    </div>
    <div id="search-results">All ads</div>

    <div class="new-ad">
        <h2>➕ Add Advertisement</h2>
        <form id="ad-form">
            <input type="text" id="title" placeholder="Title" required>
            <textarea id="content" placeholder="Content" rows="4" required></textarea>
            
            <div style="display:flex;gap:10px;">
                <input type="number" id="price" placeholder="Price" step="0.01" style="flex:1;">
                <select id="currency" style="flex:1;">
                    <option value="RUB">RUB ₽</option>
                    <option value="USD">USD $</option>
                    <option value="EUR">EUR €</option>
                    <option value="BTC">BTC ₿</option>
                </select>
            </div>
            
            <select id="category" required>
                <option value="">Select category</option>
                <option value="sale">For Sale</option>
                <option value="buy">Wanted</option>
                <option value="service">Services</option>
                <option value="job">Jobs</option>
                <option value="other">Other</option>
            </select>
            <button type="submit">Publish</button>
        </form>
    </div>

    <div class="ads-list">
        <h2>Advertisements</h2>
        <div id="ads-container"></div>
    </div>
</div>

<script>
class BoardApp {
    constructor() { 
        this.ads = []; 
        this.init(); 
        this.updateMemoryStatus();
    }
    
    async init() {
        await this.loadAds();
        this.setupListeners();
        setInterval(() => {
            this.loadAds();
            this.updateMemoryStatus();
        }, 5000);
    }
    
    setupListeners() {
        document.getElementById('search-input').addEventListener('input', (e) => this.filterAds(e.target.value));
        document.getElementById('ad-form').addEventListener('submit', (e) => { e.preventDefault(); this.addAd(); });
    }
    
    async loadAds() {
        try {
            const res = await fetch('/ads');
            if (res.ok) {
                this.ads = await res.json();
                this.filterAds(document.getElementById('search-input').value);
            }
        } catch(e) {
            console.error('Error loading ads:', e);
        }
    }
    
    async updateMemoryStatus() {
        try {
            const res = await fetch('/status');
            if (res.ok) {
                const data = await res.json();
                document.getElementById('mem-total').textContent = data.total + ' bytes';
                document.getElementById('mem-used').textContent = data.used + ' bytes';
                document.getElementById('mem-free').textContent = data.free + ' bytes';
                document.getElementById('mem-ads').textContent = data.adCount + '/' + data.maxAds;
            } else {
                const status = 'Status unavailable (HTTP ' + res.status + ')';
                document.getElementById('mem-total').textContent = status;
                document.getElementById('mem-used').textContent = status;
                document.getElementById('mem-free').textContent = status;
                document.getElementById('mem-ads').textContent = status;
            }
        } catch(e) {
            console.error('Error fetching status:', e);
            const status = 'Status unavailable: ' + e.message;
            document.getElementById('mem-total').textContent = status;
            document.getElementById('mem-used').textContent = status;
            document.getElementById('mem-free').textContent = status;
            document.getElementById('mem-ads').textContent = status;
        }
    }
    
    filterAds(text) {
        text = text.toLowerCase().trim();
        let filtered = text === '' ? [...this.ads] : this.ads.filter(ad =>
            (ad.title && ad.title.toLowerCase().includes(text)) || 
            (ad.content && ad.content.toLowerCase().includes(text))
        );
        document.getElementById('search-results').textContent = 
            text === '' ? `All ads (${filtered.length})` : `Found: ${filtered.length}`;
        this.renderAds(filtered);
    }
    
    renderAds(adsList) {
        const container = document.getElementById('ads-container');
        container.innerHTML = '';
        if (adsList.length === 0) {
            container.innerHTML = '<div class="no-ads">No ads found</div>';
            return;
        }
        adsList.sort((a,b)=>b.timestamp-a.timestamp).forEach(ad => {
            const div = document.createElement('div');
            div.className = 'ad-card';
            div.innerHTML = `
                <div class="ad-header">
                    <div class="ad-title">${this.escapeHtml(ad.title)}</div>
                    <span class="ad-category">${this.escapeHtml(ad.category)}</span>
                </div>
                <div>${this.escapeHtml(ad.content)}</div>
                ${ad.price ? `<div class="price">${ad.price} ${ad.currency||''}</div>` : ''}
                <div style="margin-top:10px;font-size:13px;color:#666;">
                    ID: ${ad.id} • ${ad.timeString||''}
                    <button class="delete-btn" onclick="app.deleteAd(${ad.id})" style="float:right">Delete</button>
                </div>
            `;
            container.appendChild(div);
        });
    }
    
    async addAd() {
        const formData = new FormData();
        formData.append('title', document.getElementById('title').value);
        formData.append('content', document.getElementById('content').value);
        formData.append('category', document.getElementById('category').value);
        formData.append('price', document.getElementById('price').value);
        formData.append('currency', document.getElementById('currency').value);

        try {
            const res = await fetch('/post', {method:'POST', body:formData});
            const result = await res.json();
            if (result.status === 'success') {
                document.getElementById('ad-form').reset();
                this.loadAds();
                this.updateMemoryStatus();
                alert(`✅ Ad added successfully!\n\n` +
                      `📌 ID: ${result.id}\n` +
                      `📊 Total ads: ${result.adCount}/${result.maxAds}\n` +
                      `💾 Memory free: ${result.freeBytes} bytes\n` +
                      `📝 Title: ${formData.get('title')}`);
            } else {
                alert('❌ Error: ' + result.message);
            }
        } catch(e) { 
            alert("❌ Error adding ad: " + e.message); 
        }
    }
    
    async deleteAd(id) {
        if (!confirm('Delete this ad?')) return;
        const fd = new FormData(); 
        fd.append('id', id);
        try {
            const res = await fetch('/delete', {method:'POST', body:fd});
            const result = await res.json();
            if (result.status === 'success') {
                this.loadAds();
                this.updateMemoryStatus();
                alert(`🗑️ Ad deleted successfully!\n\n` +
                      `📌 ID: ${id}\n` +
                      `📊 Total ads: ${result.adCount}/${result.maxAds}\n` +
                      `💾 Memory free: ${result.freeBytes} bytes`);
            } else {
                alert('❌ Error: ' + result.message);
            }
        } catch(e) {
            alert("❌ Error deleting ad: " + e.message);
        }
    }
    
    escapeHtml(t) {
        const d = document.createElement('div'); d.textContent = t; return d.innerHTML;
    }
}

const app = new BoardApp();
</script>
</body></html>
)rawliteral";

// ====================== PROTOTYPES ======================
void checkFreeSpace();
void updateTimeString(Advertisement &ad);
void saveData();
void loadData();

void handleRoot();
void handlePostAd();
void handleGetAds();
void handleDeleteAd();
void handleGetStatus();

// ====================== SETUP ======================
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n=== MBS Movable Bartik Storage " + String(ver) + " (WiFi Only) ===");

  if (!SPIFFS.begin(true)) {
    Serial.println("SPIFFS error!");
    return;
  }
  checkFreeSpace();

  WiFi.softAP(ssid.c_str(), password);
  Serial.print("WiFi AP started. IP address: ");
  Serial.println(WiFi.softAPIP());

  loadData();

  server.on("/", HTTP_GET, handleRoot);
  server.on("/post", HTTP_POST, handlePostAd);
  server.on("/ads", HTTP_GET, handleGetAds);
  server.on("/delete", HTTP_POST, handleDeleteAd);
  server.on("/status", HTTP_GET, handleGetStatus);

  server.onNotFound([]() {
    server.send(404, "application/json", "{\"status\":\"error\",\"message\":\"Not found\"}");
  });

  server.begin();
  Serial.println("Web server started");
  Serial.println("Available endpoints:");
  Serial.println("  /      - Main page");
  Serial.println("  /post  - Add ad (POST)");
  Serial.println("  /ads   - Get all ads (GET)");
  Serial.println("  /delete - Delete ad (POST)");
  Serial.println("  /status - Get memory status (GET)");
}

void loop() {
  server.handleClient();
}

// ====================== HELPER FUNCTIONS ======================
void checkFreeSpace() {
  Serial.println("=== SPIFFS ===");
  Serial.printf("Total: %d bytes\n", SPIFFS.totalBytes());
  Serial.printf("Used:  %d bytes\n", SPIFFS.usedBytes());
  Serial.printf("Free:  %d bytes\n", SPIFFS.totalBytes() - SPIFFS.usedBytes());
  Serial.printf("Ads: %d/%d\n", adCount, MAX_ADS);
  Serial.println("==============");
}

void handleGetStatus() {
  Serial.println("Status request received");
  
  DynamicJsonDocument doc(256);
  doc["total"] = SPIFFS.totalBytes();
  doc["used"] = SPIFFS.usedBytes();
  doc["free"] = SPIFFS.totalBytes() - SPIFFS.usedBytes();
  doc["adCount"] = adCount;
  doc["maxAds"] = MAX_ADS;
  
  String json;
  serializeJson(doc, json);
  
  Serial.println("Status response: " + json);
  server.send(200, "application/json", json);
}

void handleRoot() {
  String html = String(INDEX_HTML);
  html.replace("{{VERSION}}", ver);
  server.send(200, "text/html", html);
}

void handlePostAd() {
  checkFreeSpace();
  
  if (adCount >= MAX_ADS) {
    server.send(507, "application/json", "{\"status\":\"error\",\"message\":\"Ad limit reached\"}");
    return;
  }

  if (server.hasArg("title") && server.hasArg("content") && server.hasArg("category")) {
    // ===== MEMORY CHANGE: ADD AD =====
    Serial.println("\n=== MEMORY CHANGE: ADD AD ===");
    Serial.printf("Ad ID: %u\n", nextId);
    Serial.printf("Title: %s\n", server.arg("title").c_str());
    Serial.printf("Category: %s\n", server.arg("category").c_str());
    Serial.printf("Price: %s %s\n", server.arg("price").c_str(), server.arg("currency").c_str());
    Serial.printf("Total ads before: %d\n", adCount);
    Serial.printf("Memory free before: %d bytes\n", SPIFFS.totalBytes() - SPIFFS.usedBytes());
    
    Advertisement &ad = ads[adCount];
    ad.id = nextId++;
    ad.title = server.arg("title");
    ad.content = server.arg("content");
    ad.category = server.arg("category");
    ad.price = server.arg("price");
    ad.currency = server.arg("currency");
    ad.timestamp = millis();
    updateTimeString(ad);

    adCount++;
    saveData();
    checkFreeSpace();
    
    Serial.printf("Total ads after: %d\n", adCount);
    Serial.printf("Memory free after: %d bytes\n", SPIFFS.totalBytes() - SPIFFS.usedBytes());
    Serial.println("======================================\n");

    DynamicJsonDocument response(256);
    response["status"] = "success";
    response["id"] = ad.id;
    response["adCount"] = adCount;
    response["maxAds"] = MAX_ADS;
    response["freeBytes"] = SPIFFS.totalBytes() - SPIFFS.usedBytes();
    String jsonResponse;
    serializeJson(response, jsonResponse);
    server.send(200, "application/json", jsonResponse);
  } else {
    server.send(400, "application/json", "{\"status\":\"error\",\"message\":\"Please fill all required fields\"}");
  }
}

void handleGetAds() {
  DynamicJsonDocument doc(8192);
  JsonArray arr = doc.to<JsonArray>();
  for (int i = 0; i < adCount; i++) {
    JsonObject obj = arr.createNestedObject();
    obj["id"] = ads[i].id;
    obj["title"] = ads[i].title;
    obj["content"] = ads[i].content;
    obj["category"] = ads[i].category;
    obj["price"] = ads[i].price;
    obj["currency"] = ads[i].currency;
    obj["timestamp"] = ads[i].timestamp;
    obj["timeString"] = ads[i].timeString;
  }
  String json;
  serializeJson(doc, json);
  server.send(200, "application/json", json);
}

void handleDeleteAd() {
  if (server.hasArg("id")) {
    uint32_t id = server.arg("id").toInt();
    for (int i = 0; i < adCount; i++) {
      if (ads[i].id == id) {
        // ===== MEMORY CHANGE: DELETE AD =====
        Serial.println("\n=== MEMORY CHANGE: DELETE AD ===");
        Serial.printf("Ad ID: %u\n", id);
        Serial.printf("Title: %s\n", ads[i].title.c_str());
        Serial.printf("Category: %s\n", ads[i].category.c_str());
        Serial.printf("Total ads before: %d\n", adCount);
        Serial.printf("Memory free before: %d bytes\n", SPIFFS.totalBytes() - SPIFFS.usedBytes());
        
        for (int j = i; j < adCount-1; j++) ads[j] = ads[j+1];
        adCount--;
        saveData();
        checkFreeSpace();
        
        Serial.printf("Total ads after: %d\n", adCount);
        Serial.printf("Memory free after: %d bytes\n", SPIFFS.totalBytes() - SPIFFS.usedBytes());
        Serial.println("======================================\n");
        
        DynamicJsonDocument response(256);
        response["status"] = "success";
        response["adCount"] = adCount;
        response["maxAds"] = MAX_ADS;
        response["freeBytes"] = SPIFFS.totalBytes() - SPIFFS.usedBytes();
        String jsonResponse;
        serializeJson(response, jsonResponse);
        server.send(200, "application/json", jsonResponse);
        return;
      }
    }
  }
  server.send(404, "application/json", "{\"status\":\"error\",\"message\":\"Ad not found\"}");
}

void saveData() {
  File file = SPIFFS.open("/data.json", "w");
  if (!file) return;
  DynamicJsonDocument doc(8192);
  doc["nextId"] = nextId;
  JsonArray arr = doc.createNestedArray("ads");
  for (int i = 0; i < adCount; i++) {
    JsonObject obj = arr.createNestedObject();
    obj["id"] = ads[i].id;
    obj["title"] = ads[i].title;
    obj["content"] = ads[i].content;
    obj["category"] = ads[i].category;
    obj["price"] = ads[i].price;
    obj["currency"] = ads[i].currency;
    obj["timestamp"] = ads[i].timestamp;
    obj["timeString"] = ads[i].timeString;
  }
  serializeJson(doc, file);
  file.close();
}

void loadData() {
  if (!SPIFFS.exists("/data.json")) return;
  File file = SPIFFS.open("/data.json", "r");
  if (!file) return;
  DynamicJsonDocument doc(8192);
  if (deserializeJson(doc, file) == DeserializationError::Ok) {
    nextId = doc["nextId"] | 1;
    JsonArray arr = doc["ads"];
    adCount = 0;
    for (JsonObject obj : arr) {
      if (adCount >= MAX_ADS) break;
      ads[adCount].id = obj["id"];
      ads[adCount].title = obj["title"].as<String>();
      ads[adCount].content = obj["content"].as<String>();
      ads[adCount].category = obj["category"].as<String>();
      ads[adCount].price = obj["price"].as<String>();
      ads[adCount].currency = obj["currency"].as<String>();
      ads[adCount].timestamp = obj["timestamp"];
      ads[adCount].timeString = obj["timeString"].as<String>();
      adCount++;
    }
  }
  file.close();
}

void updateTimeString(Advertisement &ad) {
  time_t now = time(nullptr);
  struct tm* info = localtime(&now);
  char buf[20];
  strftime(buf, sizeof(buf), "%H:%M %d.%m.%Y", info);
  ad.timeString = String(buf);
}
