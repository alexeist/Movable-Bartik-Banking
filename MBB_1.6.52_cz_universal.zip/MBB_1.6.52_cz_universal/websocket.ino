// Инициализация WebSocket
void setupWebSocket() {
  webSocket.begin();
  webSocket.onEvent(webSocketEvent);
  
  // Инициализация массива подключенных клиентов
  for (int i = 0; i < 10; i++) {
    connectedClients[i].username = "";
    connectedClients[i].authenticated = false;
  }
  
  Serial.println("WebSocket server started on port 81");
}

// Обработчик событий WebSocket
// Обработчик событий WebSocket
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  switch(type) {
    case WStype_DISCONNECTED:
      Serial.printf("[%u] WebSocket disconnected!\n", num);
      if (num < 10) {
        connectedClients[num].username = "";
        connectedClients[num].authenticated = false;
      }
      break;
      
    case WStype_CONNECTED:
      {
        IPAddress ip = webSocket.remoteIP(num);
        Serial.printf("[%u] WebSocket connected from %d.%d.%d.%d\n", num, ip[0], ip[1], ip[2], ip[3]);
        // При подключении клиент еще не аутентифицирован
        if (num < 10) {
          connectedClients[num].username = "";
          connectedClients[num].authenticated = false;
        }
      }
      break;
      
    case WStype_TEXT:
      {
        updateActivityTime();  // Обновляем при активности
        lastUserActionTime = millis();

        String message = String((char*)payload);
        Serial.printf("[%u] WebSocket received: %s\n", num, message.c_str());
        
        // Обработка аутентификации через WebSocket
        if (message.startsWith("AUTH:")) {
          String sessionId = message.substring(5);
          Session* session = findSession(sessionId);
          if (session && num < 10) {
            connectedClients[num].username = String(session->username);
            connectedClients[num].authenticated = true;
            webSocket.sendTXT(num, "AUTH_SUCCESS:" + String(session->username));
            Serial.println("WebSocket authenticated: " + String(session->username));
          } else {
            webSocket.sendTXT(num, "AUTH_FAILED");
          }
        }
        
        // Обработка ping-сообщений для поддержания соединения
        if (message == "PING") {
          webSocket.sendTXT(num, "PONG");
        }
      }
      break;
      
    case WStype_BIN:
      Serial.printf("[%u] WebSocket binary data received, length: %u\n", num, length);
      break;
      
    case WStype_ERROR:
      Serial.printf("[%u] WebSocket error!\n", num);
      break;
      
    case WStype_FRAGMENT_TEXT_START:
    case WStype_FRAGMENT_BIN_START:
    case WStype_FRAGMENT:
    case WStype_FRAGMENT_FIN:
      // Игнорируем фрагментированные сообщения (обычно не используются)
      break;
      
    case WStype_PING:
      Serial.printf("[%u] WebSocket ping received\n", num);
      break;
      
    case WStype_PONG:
      Serial.printf("[%u] WebSocket pong received\n", num);
      break;
      
    default:
      Serial.printf("[%u] Unknown WebSocket event type: %u\n", num, type);
      break;
  }
}

// Отправка сообщения конкретному пользователю
void sendToUser(String username, String message) {
  for (int i = 0; i < 10; i++) {
    if (connectedClients[i].authenticated && connectedClients[i].username == username) {
      webSocket.sendTXT(i, message);
      Serial.println("Notification sent to " + username + ": " + message);
      return;
    }
  }
  Serial.println("User " + username + " not connected for notification");
}

// Уведомление пользователя о поступлении денег
void notifyUser(String username, String message) {
  sendToUser(username, "NOTIFICATION:" + message);
}

// Функция для отправки уведомления о платеже
void notifyPaymentReceived(String toUser, String fromUser, float amount, String currency) {
  String message = "You have received " + String(amount, 2) + " " + currency + " from " + fromUser;
  notifyUser(toUser, message);
  
  // Также логируем уведомление
  Serial.println("Payment notification sent to " + toUser + ": " + message);
}
