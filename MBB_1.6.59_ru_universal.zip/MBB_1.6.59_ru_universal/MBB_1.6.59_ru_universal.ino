
/* Movable Bartik Banking server
    This software are shared under MIT license. Please use this OpenSourse soft according MIT license
     on 1.6.59_en_universal  -
     1 makePayment is String and return the answer

*/


/* Movable Bartik Banking server  */
const char* ver = "1.6.59_ru";

/*Debugging*/
bool debug = true;
bool debug2 = true;
const bool CLEAR_SPIFF = true;  //очистка SPIFF по умолчанию. Для апгрейда ТУРН ОФФ
const char* LINE1 = "=================================";

#include <Arduino.h>
#include <ArduinoOTA.h>
#include <WebSocketsServer.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <WiFi.h>
#include <SPIFFS.h>
#include <SD.h>
#include <SPI.h>
#include <ESPmDNS.h>
#include <driver/gpio.h>  // Для C3 gpio_wakeup_enable
#include "esp_sleep.h"
#include "soc/rtc.h"
#include <pgmspace.h>



// === АВТОМАТИЧЕСКАЯ НАСТРОЙКА ПОД C3/S3 ===
#if defined(CONFIG_IDF_TARGET_ESP32C3)
#define SD_CS       GPIO_NUM_7
#define SD_SCK      GPIO_NUM_6
#define SD_MOSI     GPIO_NUM_4
#define SD_MISO     GPIO_NUM_5

#define ESP_SLEEP_WAKEUP_PIN  GPIO_NUM_2
#define LED_BUILTIN           GPIO_NUM_8
#define BATTERY_PIN           GPIO_NUM_1    


#elif defined(CONFIG_IDF_TARGET_ESP32S3)
#define SD_CS       GPIO_NUM_10
#define SD_SCK      GPIO_NUM_12
#define SD_MOSI     GPIO_NUM_13
#define SD_MISO     GPIO_NUM_11

#define ESP_SLEEP_WAKEUP_PIN  GPIO_NUM_0
#define LED_BUILTIN           GPIO_NUM_21
#define BATTERY_PIN           GPIO_NUM_1    
#else           //all other modules ESP32 WROOM and ...
#define SD_CS       GPIO_NUM_5
#define SD_SCK      GPIO_NUM_18
#define SD_MOSI     GPIO_NUM_23
#define SD_MISO     GPIO_NUM_19

#define ESP_SLEEP_WAKEUP_PIN  GPIO_NUM_13
#define LED_BUILTIN           GPIO_NUM_2
#define BATTERY_PIN           GPIO_NUM_35
#endif

#define LOW_BAT_WARNING   3.65f   // предупреждение
#define LOW_BAT_CRITICAL  3.45f   // критический (очень важно!)

#define SPI_SPEED 1000000  // Уменьшите скорость до 1 MHz если есть проблемы
//#define SPI_SPEED 4000000
// ====================== POWER PROTECTION ======================

unsigned long lastBatteryCheck = 0;
float voltage = 4.0;   // нормальное напряжение на батарее


// Файлы на SD-карте
const char* sdUsersFilename = "/MBB/users.bin";
const char* sdTransactionsFilename = "/MBB/transactions.bin";
const char* sdCurrenciesFilename = "/MBB/currencies.bin";

// Файлы в SPIFFS (для обратной совместимости)
const char* usersFilename = "/users.bin";
const char* transactionsFilename = "/transactions.bin";
const char* currenciesFilename = "/currencies.bin";

//настройка wakeup and sleep

#define DEEP_SLEEP_TIMEOUT 1 * 60 * 1000  // 1 минут в миллисекундах
unsigned long deepSleepStartTime = 0;
bool sleepPending = false;

#ifndef LED_BUILTIN
#define LED_BUILTIN 2
#endif

#define AP_SSID "MBB_" + String(ver)
#define AP_PASSWORD ""
#define OTA_PASSWORD ""
#define MBB_HOST "mbb"
// Базовые лимиты для SPIFFS (безопасные для WROOM)
#define MAX_USERS           40
#define MAX_TRANSACTIONS    600
#define MAX_CURRENCIES      4
#define MAX_USERS_ONLINE    10

// Расширенные лимиты для SD-карты
#define SD_MAX_USERS           4000
#define SD_MAX_TRANSACTIONS    40000
#define SD_MAX_CURRENCIES      400
#define SD_MAX_USERS_ONLINE    10


// Глобальная переменная должна сохраняться в памяти во врем сна хранится и при прбуждении вводится в память последнее значение
//инициируется только один раз при первой регистрации первого пользователя - Админа
static unsigned long TIME_STAMP  = micros();
static unsigned long  lastPrint  = 0;

enum UserRole { ROLE_USER = 0, ROLE_ADMIN = 1, ROLE_BLOCKED = 2};
enum UserState { STATE_ACTIVE = 0, STATE_BLOCKED = 1, STATE_SUSPENDED = 2, STATE_BANKROUT = 3 };

struct User {
  char username[16];
  char password[16];
  unsigned long registrationTime;
  char currency[8];
  float balance;
  float debt;
  uint8_t rating;
  uint8_t state;
  UserRole role;
};

struct Currency {
  char name[15];
  char abbr[4];
  float rate;  // курс к BRT (базовой валюте)
};

struct Transaction {
  unsigned long timestamp;
  char fromUser[16];
  char toUser[16];
  float amount;
  char currency[8];
  char note[32];      // здесь будем хранить описание тран0закции
  float exchangeRate; // курс на момент транзакции
  char blockchain[11];
};

// Структура для хранения сессий
struct Session {
  char sessionId[33];
  char username[32];
  unsigned long expiryTime;
};


unsigned long lastActivityTime   = 0;
unsigned long lastActivityCheck  = 0;
bool   hasActivity               = false;
bool isAuthenticated             = false;
String currentUser               = "";         // последний активный пользователь, онлайн может быть несколько

UserRole currentUserRole         = ROLE_USER;  // По умолчанию USER, не BLOCKED
bool sdCardAvailable             = false;      // Флаг доступности SD-карты

AsyncWebServer server(80);
WebSocketsServer webSocket = WebSocketsServer(81); // WebSocket на порту 81

// Структура для хранения подключенных клиентов
struct ConnectedClient {
  String username;
  bool authenticated;
};
ConnectedClient connectedClients[10]; // Максимум 10 подключений

bool ledState = false;
unsigned long startTime = 0;

User users[MAX_USERS];
Transaction transactions[MAX_TRANSACTIONS];
Currency currencies[MAX_CURRENCIES];
Session sessions[10]; // Максимум 10 активных сессий

int userCount = 0;
unsigned long lastUserActionTime = 0;
int transactionCount = 0;
int currencyCount = 3;
const char* sessionCookieName = "ESP32_BARTIK_SESSION";
const unsigned long SESSION_DURATION =  30 * 60 * 1000; // 30 min

// Массивы букв для генерации псевдонима
const char consonants[] = "bcdfghjklmnpqrstvwxyz";
const char vowels[] = "aeiou";
const int CONSONANTS_COUNT = 21;
const int VOWELS_COUNT = 5;

// Прототипы функций
void setupAuth();
bool registerUser(String username, String password, String currency = "BRT");
bool loginUser(String username, String password);
bool userExists(String username);
void saveUsersToFile();
void loadUsersFromFile();
String hashPassword(String password);
void logoutUser();
User* getUserByUsername(String username);
String makePayment(String fromUser, String toUser, float amount, String currency);
void saveTransactionsToFile();
void loadTransactionsFromFile();
String generateBlockchainHash(Transaction* transaction, String previousHash = "");
String getDashboardHTML(String username);
void loadCurrenciesFromFile();
void saveCurrenciesToFile();
void initializeDefaultCurrencies();
float convertCurrency(float amount, String fromCurrency, String toCurrency);
String getAdminPanelHTML();
String getCurrencyManagementHTML();
String getUserManagementHTML();
String getSystemManagementHTML();
void debugUsers();
void resetUsersFile();
void checkTransactionLimit();  // Проверка и сигнализация лимита транзакций
void handleExportAndResetUsers(AsyncWebServerRequest *request);
void handleExportAndResetTransactions(AsyncWebServerRequest *request);
void handleExportAndResetCurrencies(AsyncWebServerRequest *request);

// Функции для работы с SD-картой
bool initSDCard();
bool migrateDataToSD();
bool fileExists(const char* filename);
File openFileForRead(const char* filename);
File openFileForWrite(const char* filename);

// WebSocket функции
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length);
void notifyUser(String username, String message);
void sendToUser(String username, String message);
void setupWebSocket();
void notifyPaymentReceived(String toUser, String fromUser, float amount, String currency);

// Функции для работы с SD-картой
bool initSDCard() {
  Serial.println("Initializing SD card...");

  // Настройка SPI с явным указанием пинов
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  // SPI.begin(18, 19, 23, SD_CS);  // SCK, MISO, MOSI, CS

  if (!SD.begin(SD_CS, SPI, SPI_SPEED)) {
    Serial.println("SD Card initialization failed!");
    Serial.println("Trying alternative initialization...");

    // Альтернативная попытка инициализации
    if (!SD.begin(SD_CS)) {
      Serial.println("SD Card initialization completely failed!");
      return false;
    }
  }

  // Проверка типа карты
  uint8_t  cardType = CARD_NONE;
  cardType = SD.cardType();
  if (cardType == CARD_NONE) {
    Serial.println("No SD card attached");
    return false;
  }

  Serial.print("SD Card Type: ");
  if (cardType == CARD_MMC) {
    Serial.println("MMC");
  } else if (cardType == CARD_SD) {
    Serial.println("SDSC");
  } else if (cardType == CARD_SDHC) {
    Serial.println("SDHC");
  } else {
    Serial.println("UNKNOWN");
  }

  uint64_t cardSize = SD.cardSize() / (1024 * 1024);
  uint64_t usedSpace = SD.usedBytes() / (1024 * 1024);
  Serial.printf("SD Card Size: %lluMB\n", cardSize);
  Serial.printf("Used Space: %lluMB\n", usedSpace);
  Serial.printf("Free Space: %lluMB\n", cardSize - usedSpace);

  return true;
}

void updateUserActivity() {
  lastUserActionTime = millis();
}

bool migrateDataToSD() {
  Serial.println("Starting data migration to SD card...");
  bool success = true;

  // Миграция пользователей
  if (SPIFFS.exists(usersFilename)) {
    File spiffsFile = SPIFFS.open(usersFilename, "r");
    File sdFile = SD.open(sdUsersFilename, "w");
    if (spiffsFile && sdFile) {
      size_t fileSize = spiffsFile.size();
      uint8_t buffer[256];
      size_t bytesRead;

      while ((bytesRead = spiffsFile.read(buffer, sizeof(buffer))) > 0) {
        sdFile.write(buffer, bytesRead);
      }

      spiffsFile.close();
      sdFile.close();
      Serial.printf("Users migrated to SD card (%d bytes)\n", fileSize);
    } else {
      Serial.println("Failed to migrate users");
      success = false;
    }
  }

  // Миграция транзакций
  if (SPIFFS.exists(transactionsFilename)) {
    File spiffsFile = SPIFFS.open(transactionsFilename, "r");
    File sdFile = SD.open(sdTransactionsFilename, "w");
    if (spiffsFile && sdFile) {
      size_t fileSize = spiffsFile.size();
      uint8_t buffer[256];
      size_t bytesRead;

      while ((bytesRead = spiffsFile.read(buffer, sizeof(buffer))) > 0) {
        sdFile.write(buffer, bytesRead);
      }

      spiffsFile.close();
      sdFile.close();
      Serial.printf("Transactions migrated to SD card (%d bytes)\n", fileSize);
    } else {
      Serial.println("Failed to migrate transactions");
      success = false;
    }
  }

  // Миграция валют
  if (SPIFFS.exists(currenciesFilename)) {
    File spiffsFile = SPIFFS.open(currenciesFilename, "r");
    File sdFile = SD.open(sdCurrenciesFilename, "w");
    if (spiffsFile && sdFile) {
      size_t fileSize = spiffsFile.size();
      uint8_t buffer[256];
      size_t bytesRead;

      while ((bytesRead = spiffsFile.read(buffer, sizeof(buffer))) > 0) {
        sdFile.write(buffer, bytesRead);
      }

      spiffsFile.close();
      sdFile.close();
      Serial.printf("Currencies migrated to SD card (%d bytes)\n", fileSize);
    } else {
      Serial.println("Failed to migrate currencies");
      success = false;
    }
  }

  if (success) {
    Serial.println("Data migration completed successfully");
  } else {
    Serial.println("Data migration completed with errors");
  }

  return success;
}

bool fileExists(const char* filename) {
  if (sdCardAvailable) {
    return SD.exists(filename);
  } else {
    return SPIFFS.exists(filename);
  }
}

File openFileForRead(const char* filename) {
  if (sdCardAvailable) {
    return SD.open(filename, "r");
  } else {
    return SPIFFS.open(filename, "r");
  }
}

File openFileForWrite(const char* filename) {
  if (sdCardAvailable) {
    return SD.open(filename, "w");
  } else {
    return SPIFFS.open(filename, "w");
  }
}
/////////////////////////////

// Функции для работы с сессиями
String generateSessionId() {
  String sessionId = "";
  for (int i = 0; i < 32; i++) {
    int randomValue = random(0, 16);
    sessionId += String(randomValue, HEX);
  }
  return sessionId;
}

Session* findSession(String sessionId) {
  for (int i = 0; i < 10; i++) {
    if (String(sessions[i].sessionId) == sessionId && millis() < sessions[i].expiryTime) {
      return &sessions[i];
    }
  }
  return nullptr;
}

String createSession(String username) {
  // Удаляем просроченные сессии
  for (int i = 0; i < 10; i++) {
    if (millis() >= sessions[i].expiryTime) {
      memset(&sessions[i], 0, sizeof(Session));
    }
  }

  // Ищем свободный слот
  for (int i = 0; i < 10; i++) {
    if (sessions[i].expiryTime == 0 || millis() >= sessions[i].expiryTime) {
      String newSessionId = generateSessionId();
      strncpy(sessions[i].sessionId, newSessionId.c_str(), sizeof(sessions[i].sessionId) - 1);
      strncpy(sessions[i].username, username.c_str(), sizeof(sessions[i].username) - 1);
      sessions[i].expiryTime = millis() + SESSION_DURATION;

      //      Serial.println("New sessins is created: " + username + " (ID: " + newSessionId.substring(0, 8) + "...)");
      return newSessionId;
    }
  }
  Serial.println("No free slots for user session: " + username);
  return ""; // Нет свободных слотов
}

void deleteSession(String sessionId) {
  for (int i = 0; i < 10; i++) {
    if (String(sessions[i].sessionId) == sessionId) {
      Serial.println("Deleted session for: " + String(sessions[i].username));
      memset(&sessions[i], 0, sizeof(Session));
      break;
    }
  }
}

int getActiveSessionsCount() {
  int count = 0;
  for (int i = 0; i < 10; i++) {
    if (sessions[i].expiryTime > 0 && millis() < sessions[i].expiryTime) {
      count++;
    }
  }
  return count;
}


String getCookieValue(AsyncWebServerRequest *request, String cookieName) {
  if (request->hasHeader("Cookie")) {
    String cookie = request->getHeader("Cookie")->value();
    int start = cookie.indexOf(cookieName + "=");
    if (start != -1) {
      start += cookieName.length() + 1;
      int end = cookie.indexOf(";", start);
      if (end == -1) end = cookie.length();
      return cookie.substring(start, end);
    }
  }
  return "";
}


bool checkAuth(AsyncWebServerRequest *request) {
  String sessionId = getCookieValue(request, sessionCookieName);
  if (sessionId != "") {
    Session* session = findSession(sessionId);
    if (session) {
      currentUser = String(session->username);
      User* user = getUserByUsername(currentUser);
      if (user) {
        currentUserRole = user->role;
        isAuthenticated = true;
        updateActivityTime();  // Добавь: активность при запросе!
        // Обновляем время expiry сессии
        session->expiryTime = millis() + SESSION_DURATION;
        return true;
      }
    }
  }
  isAuthenticated = false;
  currentUser = "";
  currentUserRole = ROLE_USER;
  return false;
}




void handleExportAndResetUsers(AsyncWebServerRequest *request) {
  if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
    request->redirect("/");
    return;
  }

  // Шаг 1: Логируем
  Serial.println("Admin " + currentUser + " initiated export+purge of users");

  // Для этого хэндлера: возвращаем HTML с авто-скачиванием и редиректом на очистку.
  String html = "<!DOCTYPE html><html><head><title>Export...</title></head><body>";
  html += "<script>";
  html += "setTimeout(function() {";
  html += "  window.location.href = '/export-users?download=1';";  // Скачиваем
  html += "  setTimeout(function() {";
  html += "    fetch('/resetUsers', {method: 'POST'}).then(() => {";
  html += "      alert('Export complete, data cleared!');";
  html += "      window.location.href = '/admin';";
  html += "    });";
  html += "  }, 5000);";  // 5 сек на скачивание
  html += "}, 500);";
  html += "</script>";
  html += "<p>Exporting... Please wait.</p></body></html>";

  request->send(200, "text/html", html);
}



void handleExportAndResetTransactions(AsyncWebServerRequest *request) {
  if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
    request->redirect("/");
    return;
  }

  Serial.println("Admin " + currentUser + " initiated export+purge transactions");

  String html = "<!DOCTYPE html><html><head><title>Экспорт...</title></head><body>";
  html += "<script>";
  html += "setTimeout(function() {";
  html += "  window.location.href = '/export-transactions?download=1';";
  html += "  setTimeout(function() {";
  html += "    fetch('/resetTransactions', {method: 'POST'}).then(() => {";
  html += "      alert('Export complete, transactions cleared!');";
  html += "      window.location.href = '/admin';";
  html += "    });";
  html += "  }, 2000);";
  html += "}, 500);";
  html += "</script>";
  html += "<p>Exporting transactions... Please wait.</p></body></html>";

  request->send(200, "text/html", html);
}

// Функция для обновления времени активности
void updateActivityTime() {
  lastActivityTime = millis();
}

void setup() {
  delay(10);
  pinMode(ESP_SLEEP_WAKEUP_PIN, INPUT_PULLUP);

  Serial.begin(115200);
  delay(1000);

  // Инициализация генератора случайных чисел для сессий
  randomSeed(micros());

  Serial.println("Initialization ...");
  Serial.println("MBB Version: " + String(ver));



  // Инициализация SPIFFS

  // Очистка SPIFFS (если нужно)
  if (CLEAR_SPIFF == true) {
    SPIFFS.format();
    Serial.println("SPIFFS formatted.");
  }

  // Инициализация SPIFFS
  if (!SPIFFS.begin(true)) {
    Serial.println("error SPIFFS");
    return;
  }


  // Инициализация текстов
  initTexts();

  //настройкa wakeup:
  gpio_pullup_en(ESP_SLEEP_WAKEUP_PIN);     // включаем внутренний подтягивающий резистор вверх (к 3.3В)
  gpio_pulldown_dis(ESP_SLEEP_WAKEUP_PIN);  // явно выключаем подтяжку вниз (к земле)

  // Настрой wake-up (fallback на таймер 15 мин)
  esp_sleep_enable_timer_wakeup(DEEP_SLEEP_TIMEOUT * 1000);  // us, не ms!
  // Проверяем причину пробуждения при старте
  esp_sleep_wakeup_cause_t wakeup_reason = esp_sleep_get_wakeup_cause();

#if CONFIG_IDF_TARGET_ESP32C3 || CONFIG_IDF_TARGET_ESP32S3 || CONFIG_IDF_TARGET_ESP32S2
  // Для ESP32-C3, S3, S2 (без EXT0)
  // Будим по НИЗКОМУ УРОВНЮ на пине wakeup
  gpio_wakeup_enable(ESP_SLEEP_WAKEUP_PIN, GPIO_INTR_LOW_LEVEL);
  esp_sleep_enable_gpio_wakeup();
  Serial.println("Using GPIO wakeup for ESP32-C3/S3/S2");
#else
  // Для ESP32, ESP32-WROOM (с EXT0)
  esp_sleep_enable_ext0_wakeup(ESP_SLEEP_WAKEUP_PIN, 0);
  Serial.println("Using EXT0 wakeup for ESP32/WROOM");
#endif

  if (wakeup_reason == ESP_SLEEP_WAKEUP_TIMER) {
    Serial.println("Woke up from timer");
  } else if (wakeup_reason == ESP_SLEEP_WAKEUP_UNDEFINED) {
    Serial.println("Cold boot");
    updateActivityTime();
  } else {
    Serial.printf("Woke up from: %d\n", wakeup_reason);
    updateActivityTime();
  }

  //  Serial.println("\n=== SD Card Diagnostic ===");
  Serial.printf("SD_CS Pin: %d\n", SD_CS);
  //  Serial.printf("SPI Pins - SCK:18, MISO:19, MOSI:23\n");

  // Проверка пинов
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH); // Деактивировать SD карту по умолчанию
  if (debug) {
    Serial.print("main 580. Use SD CS pin ");
    Serial.println(SD_CS);
  }
  // Проверка напряжения
  //  float voltage = 3.3; // ESP32 работает на 3.3V
  //  Serial.printf("Operating voltage: %.1fV\n", voltage);

  // Инициализация SD-карты
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);  // SCK, MISO, MOSI, CS
  sdCardAvailable = initSDCard();

  if (sdCardAvailable) {
    Serial.println("Using SD card for data storage");
    // Миграция данных при первом запуске
#undef MAX_USERS
#undef MAX_TRANSACTIONS
#undef MAX_CURRENCIES
#define   MAX_USERS         SD_MAX_USERS
#define   MAX_TRANSACTIONS  SD_MAX_TRANSACTIONS
#define   MAX_CURRENCIES    SD_MAX_CURRENCIES

    if (!SD.exists(sdUsersFilename) && (SPIFFS.exists(usersFilename) || SPIFFS.exists(transactionsFilename))) {
      migrateDataToSD();
    }
  } else {
    Serial.println("Using SPIFFS for data storage");
  }

  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, HIGH);

  lastUserActionTime = millis();
  lastActivityTime = millis(); // Инициализация времени активности

  // Загружаем данные
  loadCurrenciesFromFile();
  loadUsersFromFile();
  loadTransactionsFromFile();

  // Если проснулся по таймеру — коротко проверь и спи дальше
  if (wakeup_reason == ESP_SLEEP_WAKEUP_TIMER) {
    // Быстрая проверка: есть ли клиенты? Если да — active
    if (WiFi.softAPgetStationNum() > 0) {
      updateActivityTime();
      Serial.println("Clients detected on timer wake — staying active!");
    } else {
      Serial.println("No clients — back to sleep soon.");
      // Можно сразу sleep, но дай время на loop
    }
  }

  // Перезапусти WiFi/server только если нужно (e.g. по GPIO или если был sleep)
  //  if (wakeup_reason != ESP_SLEEP_WAKEUP_UNDEFINED) {
  Serial.println("Create an access point...");

  if (!WiFi.softAP(AP_SSID, AP_PASSWORD)) {
    Serial.println("Access point creation error!");
    return;
  }
  // успешно инициализировано Точка доступа
  // Инициализация mDNS
  if (!MDNS.begin(MBB_HOST)) {  // "mbb" — имя хоста (будет доступен как mbb.local)
    Serial.println("Error setting up MDNS responder!");
  } else {
    Serial.println("mDNS responder started: mbb.local");
    // Добавляем сервис для HTTP (порт 80)
    MDNS.addService("http", "tcp", 80);
  }


  IPAddress myIP = WiFi.softAPIP();
  Serial.println(LINE1);
  Serial.println("        ESP32 Finance Server Ready");
  Serial.println(LINE1);
  Serial.print("SSID: ");
  Serial.println(String(AP_SSID));
  Serial.printf("Password: %s\n", AP_PASSWORD);
  Serial.printf("IP address: %s\n", myIP.toString().c_str());
  Serial.println("Version: " + String(ver));
  Serial.println("Storage: " + String(sdCardAvailable ? "SD Card" : "SPIFFS"));
  Serial.println(LINE1);

  startTime = millis();
  setupAuth();

  server.begin();
  Serial.println("HTTP server started at port 80");
  Serial.println("http://" + WiFi.softAPIP().toString());

  // ДОБАВЛЯЕМ ИНИЦИАЛИЗАЦИЮ WEB SOCKET
  setupWebSocket();

  // OTA часть (обязательно!)
  ArduinoOTA.setPassword(OTA_PASSWORD); // Тот же пароль!
  ArduinoOTA.onStart([]() {
    Serial.println("OTA update started...");
  });
  ArduinoOTA.onEnd([]() {
    Serial.println("OTA update finished!");
  });

  ArduinoOTA.begin();

}

void loop() {

  // === ПРОВЕРКА ПИТАНИЯ ===
  if (millis() - lastBatteryCheck > 8000) {   // проверяем каждые 8 секунд
    lastBatteryCheck = millis();
    checkPower();
  }

  // Проверяем сессии каждые 30 сек (чтобы не спамить)
  if (millis() - lastActivityCheck > 30000) {
    lastActivityCheck = millis();

    // Проверяем текущую сессию (если есть)
    if (isAuthenticated && !currentUser.isEmpty()) {
      bool sessionValid = false;
      for (int i = 0; i < 10; i++) {
        if (String(sessions[i].username) == currentUser && millis() < sessions[i].expiryTime) {
          sessionValid = true;
          // Продлеваем сессию
          sessions[i].expiryTime = millis() + SESSION_DURATION;
          break;
        }
      }
      if (!sessionValid) {
        isAuthenticated = false;
        currentUser = "";
        currentUserRole = ROLE_USER;
        Serial.println("Session expired: logged out globally.");
      }
    }
  }

  // Обновляем активность ТОЛЬКО при реальной активности
  if (webSocket.connectedClients() > 0) {
    updateActivityTime();
    sleepPending = false;  // Сбрасываем флаг сна при активности
  }

  // Проверка таймаута для глубокого сна (только если нет активных клиентов)
  if (!sleepPending && webSocket.connectedClients() == 0) {
    if (lastActivityTime > 0 && (millis() - lastActivityTime) > DEEP_SLEEP_TIMEOUT) {
      Serial.println("No activity for 15 minutes. Preparing for deep sleep...");
      sleepPending = true;
      deepSleepStartTime = millis();
    }
  }

  // Если сон запланирован, даем время на завершение операций
  if (sleepPending && (millis() - deepSleepStartTime) > 5000) {
    vTaskDelay(pdMS_TO_TICKS(300));  // Ждём 300 мс функция из FreeRTOS
    enterDeepSleep();
  }

  //MDNS.update();  // Обновляем mDNS

  // Принт статуса (теперь lastPrint работает правильно)
  if (millis() - lastPrint > 30000) {
    lastPrint = millis();
    String authStatus = isAuthenticated ?
                        "Authenticated (" + currentUser + ", " + (currentUserRole == ROLE_ADMIN ? "Admin" : "User") + ")" :
                        "Not authenticated";
    unsigned long inactiveTime = lastActivityTime > 0 ? (millis() - lastActivityTime) / 1000 : 0;
    if (debug) {
      Serial.print("lastActivityTime: ");
      Serial.println(lastActivityTime / 1000);
      Serial.print("inactivityTime: ");
      Serial.print(inactiveTime);
      Serial.println(" cek");
    }
    Serial.print (TIME_STAMP);
    Serial.printf("[%lu сек] Memory: %d bytes, Status: %s, Inactive: %lu sec, Active sessions: %d, Storage: %s\n",
                  millis() / 1000, ESP.getFreeHeap(), authStatus.c_str(), inactiveTime, getActiveSessionsCount(),
                  sdCardAvailable ? "SD Card" : "SPIFFS");
  }


  webSocket.loop();
  ArduinoOTA.handle();
  delay(100);
}
