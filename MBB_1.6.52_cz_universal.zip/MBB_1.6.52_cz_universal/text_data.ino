// texts_data.ino - Текстовые данные для веб-интерфейса
 
// Функция инициализации текстов (значения по умолчанию)
void initTexts() {
    const char* defaultTexts[] = {
// 0-13: Správa měn
"Správa měn",
"Přidat novou měnu",
"Název měny",
"Zkratka (3 znaky)",
"Směnný kurz k BRT",
"Přidat měnu",
"Aktuální měny",
"Název měny",
"Zkratka",
"Směnný kurz k BRT",
"Akce",
"Aktualizovat",
"Smazat",
"Smazat měnu?",

// 14-29: Správa uživatelů
"Správa uživatelů",
"Jméno",
"Měna",
"Částka",
"Dluh",
"Role",
"Stav",
"Akce",
"Uživatel",
"Administrátor",
"Blokováno",
"Aktivní",
"Blokováno",
"Pozastaveno",
"Upravit",
"Smazat uživatele?",

// 30-67: Systém správy
"Správa systému",
"Stáhnout do počítače",
"Stáhnout Users.bin",
"Stáhnout Transactions.bin",
"Vymazat data",
"Vymazat uživatele",
"Vymazat transakce",
"Obnovit měny",
"VAROVÁNÍ: Tímto se smažou všichni uživatelé!",
"VAROVÁNÍ: Tímto se smažou všechny transakce!",
"VAROVÁNÍ: Tímto se měny resetují na výchozí hodnoty!",
"Importovat data (nahradit aktuální)",
"Stáhnout Users.bin",
"Stáhnout Transactions.bin",
"Stáhnout Currencies.bin",
"Nahradit VŠECHNY uživatele ze souboru?",
"Nahradit VŠECHNY transakce ze souboru?",
"Nahradit VŠECHNY měny ze souboru?",
"Informace o systému",
"Uživatelé",
"Transakce",
"Měny",
"Volné místo",
"Pracovní čas",
"Úložiště",
"Transakce",
"Aktivní relace",
"Seznam relací",
"Historie transakcí",
"Žádné transakce",
"Čas",
"Od",
"Do",
"Částka",
"Měna",
"Kurz",
"Hash",
"Poslední Zobrazeno",

// 68-73: Panel administrace
"Panel administrace",
"Panel administrace",
"Měny",
"Uživatelé",
"Systém",
"Ovládací panel",

// 74-86: Osobní účet
"Osobní účet",
"Moje údaje",
"ID",
"Částka",
"Hodnocení",
"Měna",
"Převod peněz",
"-- Vyberte příjemce --",
"Částka",
"Platba",
"Panel Administrátor",
"Domů",
"Odhlásit se",

// 87-93: Přihlášení
"Přihlášení do MBB",
"Bankovní systém MBB",
"Uživatelské jméno",
"Heslo",
"Přihlášení",
"Vytvořit nový účet",
"Verze"
};
    
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < 100; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файловой системы (если файл существует)
    loadTextsFromFS();
}

// Загрузка текстов из файловой системы (опционально)
void loadTextsFromFS() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        return;
    }
    
    int index = 0;
    while (file.available() && index < 100) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        if (line.length() > 0 && !line.startsWith("#")) {
            if (index < textCount) {
                labels[index] = line;
            }
            index++;
        }
    }
    
    file.close();
    
    if (index > 0 && index < textCount) {
        textCount = index;
    }
    
    Serial.println("Loaded " + String(index) + " texts from file system");
}

// Создание файла с текстами в файловой системе (для редактирования)
void createTextsFile() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    for (int i = 0; i < textCount; i++) {
        file.println(labels[i]);
    }
    
    file.close();
    Serial.println("Created texts file with " + String(textCount) + " entries");
}
