// texts_data.ino - Текстовые данные для веб-интерфейса
 
// Функция инициализации текстов (значения по умолчанию)
void initTexts() {
    const char* defaultTexts[] = {
// 0-13: Currency Management
"Currency Management",
"Add New Currency",
"Currency Name",
"Abbreviation (3 characters)",
"Exchange Rate to BRT",
"Add Currency",
"Current Currencies",
"Currency Name",
"Abbreviation",
"Exchange Rate to BRT",
"Actions",
"Update",
"Delete",
"Delete Currency?",

// 14-29: User Management
"User Management",
"Name",
"Currency",
"Amount",
"Debt",
"Role",
"Status",
"Action",
"User",
"Administrator",
"Blocked",
"Active",
"Blocked",
"Suspended",
"Edit",
"Delete User?",

// 30-67: Management System
"System Management",
"Download to Computer",
"Download Users.bin",
"Download Transactions.bin",
"Clear Data",
"Clear Users",
"Clear Transactions",
"Reset Currencies",
"WARNING: This will delete all users!",
"WARNING: This will delete all transactions!",
"WARNING: This will reset currencies to default values!",
"Import Data (Replace Current)",
"Download Users.bin",
"Download Transactions.bin",
"Download Currencies.bin",
"Replace ALL Users from File?",
"Replace ALL Transactions from File?",
"Replace ALL Currencies from File?",
"System Information",
"Users",
"Transactions",
"Currencies",
"Free Space",
"Time Work",
"Storage",
"Transactions",
"Active Sessions",
"Session List",
"Transaction History",
"No Transactions",
"Time",
"From",
"To",
"Amount",
"Currency",
"Rate",
"Hash",
"Last Displayed",

// 68-73: Admin Panel
"Admin Panel",
"Admin Panel",
"Currencies",
"Users",
"System",
"Control Panel",

// 74-86: Personal Account
"Personal Account",
"My Details",
"ID",
"Amount",
"Rating",
"Currency",
"Money Transfer",
"-- Select Recipient --",
"Amount",
"Payment",
"Panel Administrator",
"Home",
"Logout",

// 87-93: Login
"MBB Login",
"MBB Banking System",
"Username",
"Password",
"Login",
"Create New Account",
"Version"    
};
    
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < 100; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файловой системы (если файл существует)
    loadTextsFromFS();
}

// Загрузка текстов из файловой системы (опционально)
void loadTextsFromFS() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        return;
    }
    
    int index = 0;
    while (file.available() && index < 100) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        if (line.length() > 0 && !line.startsWith("#")) {
            if (index < textCount) {
                labels[index] = line;
            }
            index++;
        }
    }
    
    file.close();
    
    if (index > 0 && index < textCount) {
        textCount = index;
    }
    
    Serial.println("Loaded " + String(index) + " texts from file system");
}

// Создание файла с текстами в файловой системе (для редактирования)
void createTextsFile() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    for (int i = 0; i < textCount; i++) {
        file.println(labels[i]);
    }
    
    file.close();
    Serial.println("Created texts file with " + String(textCount) + " entries");
}
