#include <Arduino.h>

// В начале login.ino после #include
extern bool checkAuth(AsyncWebServerRequest *request);
extern String createSession(String username);
extern void deleteSession(String sessionId);
extern String getCookieValue(AsyncWebServerRequest *request, String cookieName);

int min(int a, int b) {
  return (a < b) ? a : b;
}
//создание уникального юзернейм для большой сети (в будущих версиях)
String generateAliasFromTimestamp(unsigned long timestamp) {
  String timestampStr = String(timestamp);
  unsigned long hash = 5381;
  
  for (int i = 0; i < timestampStr.length(); i++) {
    hash = ((hash << 5) + hash) + timestampStr.charAt(i);
  }
  
  String alias = "";
  int lettersCount = 5;
  
  for (int i = 0; i < lettersCount; i++) {
    if (i % 2 == 0) {
      int index = hash % CONSONANTS_COUNT;
      alias += consonants[index];
    } else {
      int index = hash % VOWELS_COUNT;
      alias += vowels[index];
    }
    hash = ((hash << 5) + hash) + i;
  }
  
  alias.setCharAt(0, toupper(alias.charAt(0)));
  return alias;
}

String getCurrentAlias() {
  unsigned long timestamp = millis();
  return generateAliasFromTimestamp(timestamp);
}

String generateAliasFromCustomTime(unsigned long customTime) {
  return generateAliasFromTimestamp(customTime);
}

String hashPassword(String password) {
  unsigned long hash = 5381;
  for (int i = 0; i < password.length(); i++) {
    hash = ((hash << 5) + hash) + password.charAt(i);
  }
  return String(hash);
}

String generateBlockchainHash(Transaction* transaction, String previousHash) {
  String data = String(transaction->timestamp) + 
                String(transaction->fromUser) + 
                String(transaction->toUser) + 
                String(transaction->amount) + 
                String(transaction->currency) + 
                previousHash;
  
  unsigned long hash = 5381;
  for (int i = 0; i < data.length(); i++) {
    hash = ((hash << 5) + hash) + data.charAt(i);
  }
  
  String hashStr = String(hash, HEX);
  while (hashStr.length() < 10) {
    hashStr = "0" + hashStr;
  }
  return hashStr.substring(0, 10);
}

User* getUserByUsername(String username) {
  for (int i = 0; i < userCount; i++) {
    if (String(users[i].username) == username) {
      return &users[i];
    }
  }
  return nullptr;
}
// Обновленные функции загрузки/сохранения для работы с SD-картой
void loadUsersFromFile() {
  if (fileExists(sdCardAvailable ? sdUsersFilename : usersFilename)) {
    File file = openFileForRead(sdCardAvailable ? sdUsersFilename : usersFilename);
    if (file) {
      userCount = file.read((uint8_t*)users, sizeof(User) * MAX_USERS) / sizeof(User);
      file.close();
      Serial.printf("Loaded %d users from %s\n", userCount, sdCardAvailable ? "SD card" : "SPIFFS");
    }
  } else {
    Serial.println("No users file found, starting with empty user database");
    userCount = 0;
  }
}

void saveUsersToFile() {
  File file = openFileForWrite(sdCardAvailable ? sdUsersFilename : usersFilename);
  if (file) {
    file.write((uint8_t*)users, sizeof(User) * userCount);
    file.close();
    Serial.printf("Saved %d users to %s\n", userCount, sdCardAvailable ? "SD card" : "SPIFFS");
  } else {
    Serial.println("Error saving users file");
  }
}

void loadTransactionsFromFile() {
  if (fileExists(sdCardAvailable ? sdTransactionsFilename : transactionsFilename)) {
    File file = openFileForRead(sdCardAvailable ? sdTransactionsFilename : transactionsFilename);
    if (file) {
      transactionCount = file.read((uint8_t*)transactions, sizeof(Transaction) * MAX_TRANSACTIONS) / sizeof(Transaction);
      file.close();
      Serial.printf("Loaded %d transactions from %s\n", transactionCount, sdCardAvailable ? "SD card" : "SPIFFS");
    }
  } else {
    Serial.println("No transactions file found, starting with empty transaction database");
    transactionCount = 0;
  }
}

void saveTransactionsToFile() {
  File file = openFileForWrite(sdCardAvailable ? sdTransactionsFilename : transactionsFilename);
  if (file) {
    file.write((uint8_t*)transactions, sizeof(Transaction) * transactionCount);
    file.close();
    Serial.printf("Saved %d transactions to %s\n", transactionCount, sdCardAvailable ? "SD card" : "SPIFFS");
    
  } else {
    Serial.println("Error saving transactions file");
  }
}

void checkTransactionLimit() {
  const int TRANSACTION_LIMIT = 15000;
  
  if (transactionCount >= TRANSACTION_LIMIT) {
    Serial.println("!!! CRITICAL WARNING: Transaction limit reached (" + String(transactionCount) + "/" + String(TRANSACTION_LIMIT) + ")! Export and cleanup is recommended.");
    
    // Можно добавить мигание LED или что-то, но для простоты — только лог
    if (ledState) digitalWrite(LED_BUILTIN, LOW);  // Выключаем LED
    else digitalWrite(LED_BUILTIN, HIGH);  // Включаем для сигнала
    ledState = !ledState;
    delay(200);  // Короткий миг
    digitalWrite(LED_BUILTIN, LOW);  // Выключаем
  } else if (transactionCount >= TRANSACTION_LIMIT * 0.93) {  // ~14k
    Serial.println("WARNING: Transactions close to the limit (" + String(transactionCount) + "/" + String(TRANSACTION_LIMIT) + "). Prepare for export.");
  } else if (transactionCount >= TRANSACTION_LIMIT * 0.97) {  // ~14.5k
    Serial.println("LAST WARNING: Transactions near maximum (" + String(transactionCount) + "/" + String(TRANSACTION_LIMIT) + ")!");
  }
}

void initializeDefaultCurrencies() {
  currencyCount = 3;
  
  strcpy(currencies[0].name, "Bartik");
  strcpy(currencies[0].abbr, "BRT");
  currencies[0].rate = 1.0;
  
  strcpy(currencies[1].name, "Euro");
  strcpy(currencies[1].abbr, "EUR");
  currencies[1].rate = 20.05;             // 20 Евро за Бартик
  
  strcpy(currencies[2].name, "US Dollar");
  strcpy(currencies[2].abbr, "USD");
  currencies[2].rate = 20.25;
  
  saveCurrenciesToFile();
}

void loadCurrenciesFromFile() {
  if (fileExists(sdCardAvailable ? sdCurrenciesFilename : currenciesFilename)) {
    File file = openFileForRead(sdCardAvailable ? sdCurrenciesFilename : currenciesFilename);
    if (file) {
      currencyCount = file.read((uint8_t*)currencies, sizeof(Currency) * MAX_CURRENCIES) / sizeof(Currency);
      file.close();
      Serial.printf("Loaded %d currencies from %s\n", currencyCount, sdCardAvailable ? "SD card" : "SPIFFS");
      
      if (currencyCount == 0) {
        initializeDefaultCurrencies();
      }
    }
  } else {
    Serial.println("No currencies file found, initializing with default currencies");
    initializeDefaultCurrencies();
  }
}

void saveCurrenciesToFile() {
  File file = openFileForWrite(sdCardAvailable ? sdCurrenciesFilename : currenciesFilename);
  if (file) {
    file.write((uint8_t*)currencies, sizeof(Currency) * currencyCount);
    file.close();
    Serial.printf("Saved %d currencies to %s\n", currencyCount, sdCardAvailable ? "SD card" : "SPIFFS");
  } else {
    Serial.println("Error saving currencies file");
  }
}

float convertCurrency(float amount, String fromCurrency, String toCurrency) {
  if (fromCurrency == toCurrency) return amount;
  
  float fromRate = 1.0;
  float toRate = 1.0;
  
  for (int i = 0; i < currencyCount; i++) {
    if (String(currencies[i].abbr) == fromCurrency) {
      fromRate = currencies[i].rate;
    }
    if (String(currencies[i].abbr) == toCurrency) {
      toRate = currencies[i].rate;
    }
  }
  
  // Конвертируем через BRT (базовую валюту)
  float amountInBRT = amount / fromRate;
  return amountInBRT * toRate;
}

bool userExists(String username) {
  return getUserByUsername(username) != nullptr;
}

bool registerUser(String username, String password, String currency) {
  if (userCount >= MAX_USERS) {
    Serial.println("Maximum number of users reached");
    return false;
  }
  
  if (userExists(username)) {
    Serial.println("User " + username + " already exists");
    return false;
  }
  
  if (username.length() == 0 || password.length() == 0) {
    Serial.println("Username and password cannot be empty");
    return false;
  }
  
  strncpy(users[userCount].username, username.c_str(), sizeof(users[userCount].username) - 1);
  String hashedPassword = hashPassword(password);
  strncpy(users[userCount].password, hashedPassword.c_str(), sizeof(users[userCount].password) - 1);
  
  users[userCount].registrationTime = millis();
  strncpy(users[userCount].currency, currency.c_str(), sizeof(users[userCount].currency) - 1);
   
  users[userCount].state = STATE_ACTIVE; 
  users[userCount].role = (userCount == 0) ? ROLE_ADMIN : ROLE_USER;
  users[userCount].balance = (users[userCount].role == ROLE_ADMIN)? 1000000.00 : 0.00; //admin gets 1000 000 BRT  
  users[userCount].rating = (users[userCount].role == ROLE_ADMIN)?         255 : 100;  //admin gets 255 rating
  users[userCount].debt   = (users[userCount].role == ROLE_ADMIN)?         0 : 0;      //admin gets 255 rating  
  userCount++;
  saveUsersToFile();
  
  // Логируем данные администратора
  if (userCount == 1) {

    Serial.println("SYSTEM ADMINISTRATOR CREATED:");
    Serial.println("Login: " + username);
    Serial.println("Password: " + password);
    Serial.println("Save this data in a safe place!");

  }
  
  String roleStr = (userCount == 1) ? " (Administrator)" : "";
  Serial.println("New user registered: " + username + roleStr);
  return true;
}

bool loginUser(String username, String password) {
  currentUserRole = ROLE_BLOCKED;
  User* user = getUserByUsername(username);
  if (user && user->state == STATE_ACTIVE) {
    String hashedInput = hashPassword(password);
    if (String(user->password) == hashedInput) {
      currentUserRole = user->role;
      currentUser = username;
      isAuthenticated = true;
      
      String roleStr = (currentUserRole == ROLE_ADMIN) ? " (Administrator)" : "";
      Serial.println("Successful user login: " + username + roleStr);
      
      // Детальное логирование для администратора
      if (currentUserRole == ROLE_ADMIN) {
//        Serial.println("=== ADMINISTRATOR DETAILS ===");
//        Serial.println("Login: " + username);
//        Serial.println("Entry timestamp: " + String(millis()));
        Serial.println("IP access point: " + WiFi.softAPIP().toString());
//        Serial.println(LINE1);
      }
      return true;
    }
  }
  Serial.println("Login error for user: " + username);
  return false;
}

void logoutUser() {
  isAuthenticated = false;
  currentUser = "";
  currentUserRole = ROLE_USER;
  Serial.println("User logged out");
  // Сессии удаляются через endpoint /logout
}

String makePayment(String fromUser, String toUser, float amount, String currency) {
  
  User* from = getUserByUsername(fromUser);
  User* tou = getUserByUsername(toUser);
  
// проверяем верность введенных данных  
  if (!from || !tou) {
    Serial.println("User not found");
    return "User not found";
  }
  if (from->state != STATE_ACTIVE || tou->state != STATE_ACTIVE) {
    Serial.println("One of the users is inactive");
    return "One of the users is inactive";
  }

  // Конвертируем сумму в валюту отправителя для проверки баланса
  float amountInSenderCurrency = convertCurrency(amount, currency, String(from->currency));
  
  if (from->balance < amountInSenderCurrency) {
    Serial.println("Insufficient funds");
    return "Insufficient funds";
  }

  if (amount <= 0) {
    Serial.println("Incorrect Payment, amount must be positive");
    return "Incorrect Payment, amount must be positive";
  }else{
    Serial.print("Initialize a payment");
    Serial.println(LINE1);
    Serial.print("From: ");
    Serial.print(fromUser);
    Serial.print("\tto: ");
    Serial.println(toUser);
    Serial.print("Amount: ");
    Serial.print(amount);
    Serial.println(currency);
    }
  

  
  

  
  // Конвертируем сумму в валюту получателя
  float amountInReceiverCurrency = convertCurrency(amount, currency, String(tou->currency));
  
  // Списание в валюте отправителя
  from->balance -= amountInSenderCurrency;
  // Зачисление в валюте получателя
  tou->balance += amountInReceiverCurrency;

  //если в операции участвует админ
  if(from->role == ROLE_ADMIN){
  tou->debt += amountInReceiverCurrency;
  Serial.print("The Debt of " );
  Serial.print(tou->username) ;
  Serial.print(" become ");
  Serial.println(tou->debt);   
    }
  if(tou->role == ROLE_ADMIN){
  from->debt -= amountInSenderCurrency; 
  Serial.print("The Debt of " );
  Serial.print(from->username) ;
  Serial.print(" become ");
  Serial.println(from->debt);
    }

  
  if (transactionCount >= MAX_TRANSACTIONS) {
    Serial.println("Transaction limit reached");
    return ("Transaction limit reached");
  }
  
  Transaction* transaction = &transactions[transactionCount];
  transaction->timestamp = millis();
  strncpy(transaction->fromUser, fromUser.c_str(), sizeof(transaction->fromUser) - 1);
  strncpy(transaction->toUser, toUser.c_str(), sizeof(transaction->toUser) - 1);
  transaction->amount = amount;
  strncpy(transaction->currency, currency.c_str(), sizeof(transaction->currency) - 1);
  
  // Сохраняем курс для аудита
  transaction->exchangeRate = 0;
  for (int i = 0; i < currencyCount; i++) {
    if (String(currencies[i].abbr) == currency) {
      transaction->exchangeRate = currencies[i].rate;
      break;
    }
  }
  
  String previousHash = (transactionCount > 0) ? String(transactions[transactionCount-1].blockchain) : "genesis";
  String blockchainHash = generateBlockchainHash(transaction, previousHash);
  strncpy(transaction->blockchain, blockchainHash.c_str(), sizeof(transaction->blockchain) - 1);
  
  transactionCount++;

  checkTransactionLimit();
  
  saveUsersToFile();
  saveTransactionsToFile();
  
  Serial.println("Payment completed: " + fromUser + " -> " + toUser + 
                " amount: " + String(amount) + " " + currency +
                " (in the sender's currency: " + String(amountInSenderCurrency) + " " + String(from->currency) + 
                ", in the currency of the recipient: " + String(amountInReceiverCurrency) + " " + String(tou->currency) + ")");
 
  // ДОБАВЛЯЕМ ОТПРАВКУ УВЕДОМЛЕНИЯ
  notifyPaymentReceived(toUser, fromUser, amount, currency);
  
  return ("Payment completed: " + fromUser + " -> " + toUser + 
                " amount: " + String(amount) + " " + currency );

}

void debugUsers() {
  Serial.println("=== USERS DEBAGGING ===");
  for (int i = 0; i < userCount; i++) {
    Serial.printf("User %d: %s, password: %s, role: %s\n", 
                 i, 
                 users[i].username, 
                 users[i].password,
                 users[i].role == ROLE_ADMIN ? "Admin" : "User");
  }
  Serial.println(LINE1);
}

void resetUsersFile() {
  
  Serial.println("USER FILE RESET...");
  SPIFFS.remove(usersFilename);
  Serial.println("File users.bin removed. Restart device.");
}

void handleExportAndResetCurrencies(AsyncWebServerRequest *request) {
  if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
    request->redirect("/");
    return;
  }
  
  Serial.println("Admin " + currentUser + " initiated export+currency reset");
  
  String html = "<!DOCTYPE html><html><head><title>Export...</title></head><body>";
  html += "<script>";
  html += "setTimeout(function() {";
  // Для валют экспорта нет, но можно добавить /export-currencies аналогично
  html += "  alert('Currencies are not exported (standard), reset...');";
  html += "  fetch('/resetCurrencies', {method: 'POST'}).then(() => {";
  html += "    alert('Currencies reset!');";
  html += "    window.location.href = '/admin';";
  html += "  });";
  html += "}, 500);";
  html += "</script>";
  html += "<p>Сброс валют...</p></body></html>";
  
  request->send(200, "text/html", html);
}
