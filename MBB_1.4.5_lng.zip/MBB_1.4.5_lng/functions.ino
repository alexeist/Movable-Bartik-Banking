// Объявляем глобальный массив для текстов
const int MAX_TEXTS = 100;
String labels[MAX_TEXTS];
int textCount = 0;

// Функция загрузки текстов из файла
bool loadTexts() {
    // Инициализируем значениями по умолчанию на случай ошибки
    String defaultTexts[] = {
        "Currency management",
        "Add new currency",
        "Currency name",
        "Abbreviation (3 characters)",
        "Rate to BRT",
        "Add currency",
        "Current currencies",
        "Currency name",
        "Abbreviation",
        "Rate to BRT",
        "Actions",
        "Update",
        "Delete",
        "Delete currency?",
        "User management",
        "Name",
        "Currency",
        "Amount",
        "Debt",
        "Role",
        "Status",
        "Action",
        "User",
        "Administrator",
        "Blocked",
        "Active",
        "Blocked",
        "Suspended",
        "Change",
        "Delete user?",
        "System management",
        "Data Export",
        "Download users.bin",
        "Download transactions.bin",
        "Data clearing",
        "Clear users",
        "Clear Transactions",
        "Reset currencies",
        "WARNING: This will remove all users!",
        "WARNING: This will remove all transactions!",
        "WARNING: This will reset currencies to standard!",
        "Data Import (replace current)",
        "Upload users.bin",
        "Upload transactions.bin",
        "Upload currencies.bin",
        "Replace ALL users from file?",
        "Replace ALL transactions from file?",
        "Replace ALL currencies from file?",
        "System information",
        "Users",
        "Transations",
        "Currencies",
        "Free Heap",
        "Working time",
        "Storage",
        "Transactions",
        "Active sessions",
        "List of sessions",
        "Transactions history",
        "No transactions",
        "Time",
        "From",
        "To",
        "Amount",
        "Currency",
        "Rate",
        "Hash",
        "Last displayed",
        "Admin panel",
        "Admin panel",
        "Currencies",
        "Users",
        "System",
        "Dashboard",
        "Personal account",
        "My data",
        "ID",
        "Amount",
        "Rating",
        "Currency",
        "Money transfer",
        "-- Choose a recipient --",
        "Amount",
        "Pay",
        "Admin panel",
        "Home",
        "Logout",
        "MBB Login",
        "MBB Banking System",
        "Username",
        "Password",
        "Login",
        "Create New Account",
        "Version"
    };
    
    // Сначала заполняем значениями по умолчанию
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < MAX_TEXTS; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файла
    File file = SPIFFS.open("data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        createDefaultTextsFile(defaultTexts)  ;
        Serial.println("New default texts.txt created.Please translate it to your language.");
        return false;
    }
    
    int index = 0;
    while (file.available() && index < MAX_TEXTS) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        // Пропускаем пустые строки и комментарии
        if (line.length() > 0 && !line.startsWith("#")) {
            labels[index] = line;
            index++;
        }
    }
    
    file.close();
    textCount = index;
    Serial.println("Loaded " + String(textCount) + " texts from file");
    return true;
}

// Создание файла с текстами по умолчанию
void createDefaultTextsFile(String defaultTexts[]) {
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    int count = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < count; i++) {
        file.println(defaultTexts[i]);
    }
    
    file.close();
    Serial.println("Created default texts file with " + String(count) + " entries");
}
