// Объявляем глобальный массив для текстов
const int MAX_TEXTS = 100;
String labels[MAX_TEXTS];
int textCount = 0;

// Функция загрузки текстов из файла
bool loadTexts() {
    // Инициализируем значениями по умолчанию на случай ошибки
    String defaultTexts[] = {
        "Currency management",
        "Add new currency",
        "Currency name",
        "Abbreviation (3 characters)",
        "Rate to BRT",
        "Add currency",
        "Current currencies",
        "Currency name",
        "Abbreviation",
        "Rate to BRT",
        "Actions",
        "Update",
        "Delete",
        "Delete currency?",
        "User management",
        "Name",
        "Currency",
        "Amount",
        "Debt",
        "Role",
        "Status",
        "Action",
        "User",
        "Administrator",
        "Blocked",
        "Active",
        "Blocked",
        "Suspended",
        "Change",
        "Delete user?",
        "System management",
        "Data Export",
        "Download users.bin",
        "Download transactions.bin",
        "Data clearing",
        "Clear users",
        "Clear Transactions",
        "Reset currencies",
        "WARNING: This will remove all users!",
        "WARNING: This will remove all transactions!",
        "WARNING: This will reset currencies to standard!",
        "Data Import (replace current)",
        "Upload users.bin",
        "Upload transactions.bin",
        "Upload currencies.bin",
        "Replace ALL users from file?",
        "Replace ALL transactions from file?",
        "Replace ALL currencies from file?",
        "System information",
        "Users",
        "Transations",
        "Currencies",
        "Free Heap",
        "Working time",
        "Storage",
        "Transactions",
        "Active sessions",
        "List of sessions",
        "Transactions history",
        "No transactions",
        "Time",
        "From",
        "To",
        "Amount",
        "Currency",
        "Rate",
        "Hash",
        "Last displayed",
        "Admin panel",
        "Admin panel",
        "Currencies",
        "Users",
        "System",
        "Dashboard",
        "Personal account",
        "My data",
        "ID",
        "Amount",
        "Rating",
        "Currency",
        "Money transfer",
        "-- Choose a recipient --",
        "Amount",
        "Pay",
        "Admin panel",
        "Home",
        "Logout",
        "MBB Login",
        "MBB Banking System",
        "Username",
        "Password",
        "Login",
        "Create New Account",
        "Version"
    };
    
    // Сначала заполняем значениями по умолчанию
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < MAX_TEXTS; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файла
    File file = SPIFFS.open("data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        createDefaultTextsFile(defaultTexts)  ;
        Serial.println("New default texts.txt created.Please translate it to your language.");
        return false;
    }
    
    int index = 0;
    while (file.available() && index < MAX_TEXTS) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        // Пропускаем пустые строки и комментарии
        if (line.length() > 0 && !line.startsWith("#")) {
            labels[index] = line;
            index++;
        }
    }
    
    file.close();
    textCount = index;
    Serial.println("Loaded " + String(textCount) + " texts from file");
    return true;
}

// Создание файла с текстами по умолчанию
void createDefaultTextsFile(String defaultTexts[]) {
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    int count = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < count; i++) {
        file.println(defaultTexts[i]);
    }
    
    file.close();
    Serial.println("Created default texts file with " + String(count) + " entries");
}



// Новая функция для входа в сон
void enterDeepSleep() {
  Serial.println("Entering deep sleep...");

  // Сохраняем данные
  saveUsersToFile();
  saveTransactionsToFile();
  saveCurrenciesToFile();

  // Очищаем сессии
  for (int i = 0; i < 10; i++) {
    memset(&sessions[i], 0, sizeof(Session));
  }

 if (sdCardAvailable) {
    Serial.println("Powering down SD card...");
    SD.end();
    pinMode(SD_CS, INPUT_PULLDOWN); // Переведите CS в безопасное состояние
  }

 // 2. Отключите SPI
  SPI.end();

  // Отключаем WebSocket
  webSocket.disconnect();  // Закрой все WS
  webSocket.close();

  // Отключаем сервер
  server.end();

  // Отключаем WiFi
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);

  delay(100);

  // Настройка wakeup (только GPIO или только таймер)
#if CONFIG_IDF_TARGET_ESP32C3 || CONFIG_IDF_TARGET_ESP32S3 || CONFIG_IDF_TARGET_ESP32S2
  esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);           // запрещаем любые пробуждения
  gpio_wakeup_enable(ESP_SLEEP_WAKEUP_PIN, GPIO_INTR_HIGH_LEVEL);  // разрешаем пробуждение только по пину с высоким напряжением
  esp_sleep_enable_gpio_wakeup();                                  // включаем сон с разрешением пробуждения по пину
#else
  // для платформы WROOM drvkit и др.
  esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
  esp_sleep_enable_ext0_wakeup(ESP_SLEEP_WAKEUP_PIN, 1);
#endif

  // Также включаем wakeup по таймеру на 10 минут (на всякий случай)
  esp_sleep_enable_timer_wakeup(10 * 60 * 1000000ULL);

  Serial.println("Going to sleep. Zzz...");
  esp_deep_sleep_start();
}
