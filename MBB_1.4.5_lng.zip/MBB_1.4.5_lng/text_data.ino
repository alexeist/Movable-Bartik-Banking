// texts_data.ino - Текстовые данные для веб-интерфейса
 
// Функция инициализации текстов (значения по умолчанию)
void initTexts() {
    const char* defaultTexts[] = {
        // 0-13: Управление валютами
        "Currency management",
        "Add new currency",
        "Currency name",
        "Abbreviation (3 characters)",
        "Rate to BRT",
        "Add currency",
        "Current currencies",
        "Currency name",
        "Abbreviation",
        "Rate to BRT",
        "Actions",
        "Update",
        "Delete",
        "Delete currency?",
        
        // 14-29: Управление пользователями
        "User management",
        "Name",
        "Currency",
        "Amount",
        "Debt",
        "Role",
        "Status",
        "Action",
        "User",
        "Administrator",
        "Blocked",
        "Active",
        "Blocked",
        "Suspended",
        "Change",
        "Delete user?",
        
        // 30-67: Управление системой
        "System management",
        "Data Export",
        "Download users.bin",
        "Download transactions.bin",
        "Data clearing",
        "Clear users",
        "Clear Transactions",
        "Reset currencies",
        "WARNING: This will remove all users!",
        "WARNING: This will remove all transactions!",
        "WARNING: This will reset currencies to standard!",
        "Data Import (replace current)",
        "Upload users.bin",
        "Upload transactions.bin",
        "Upload currencies.bin",
        "Replace ALL users from file?",
        "Replace ALL transactions from file?",
        "Replace ALL currencies from file?",
        "System information",
        "Users",
        "Transations",
        "Currencies",
        "Free Heap",
        "Working time",
        "Storage",
        "Transactions",
        "Active sessions",
        "List of sessions",
        "Transactions history",
        "No transactions",
        "Time",
        "From",
        "To",
        "Amount",
        "Currency",
        "Rate",
        "Hash",
        "Last displayed",
        
        // 68-73: Админ панель
        "Admin panel",
        "Admin panel",
        "Currencies",
        "Users",
        "System",
        "Dashboard",
        
        // 74-86: Личный кабинет
        "Personal account",
        "My data",
        "ID",
        "Amount",
        "Rating",
        "Currency",
        "Money transfer",
        "-- Choose a recipient --",
        "Amount",
        "Pay",
        "Admin panel",
        "Home",
        "Logout",
        
        // 87-93: Логин
        "MBB Login",
        "MBB Banking System",
        "Username",
        "Password",
        "Login",
        "Create New Account",
        "Version"
    };
    
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < 100; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файловой системы (если файл существует)
    loadTextsFromFS();
}

// Загрузка текстов из файловой системы (опционально)
void loadTextsFromFS() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        return;
    }
    
    int index = 0;
    while (file.available() && index < 100) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        if (line.length() > 0 && !line.startsWith("#")) {
            if (index < textCount) {
                labels[index] = line;
            }
            index++;
        }
    }
    
    file.close();
    
    if (index > 0 && index < textCount) {
        textCount = index;
    }
    
    Serial.println("Loaded " + String(index) + " texts from file system");
}

// Создание файла с текстами в файловой системе (для редактирования)
void createTextsFile() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    for (int i = 0; i < textCount; i++) {
        file.println(labels[i]);
    }
    
    file.close();
    Serial.println("Created texts file with " + String(textCount) + " entries");
}
