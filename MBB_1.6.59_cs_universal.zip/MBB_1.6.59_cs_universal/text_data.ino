// texts_data.ino - Текстовые данные для веб-интерфейса
 
// Функция инициализации текстов (значения по умолчанию)
void initTexts() {
const char* defaultTexts[] = {
    "Gestión de monedas",
    "Añadir nueva moneda",
    "Nombre de la moneda",
    "Abreviatura (3 caracteres)",
    "Tipo de cambio a BRT",
    "Añadir moneda",
    "Monedas actuales",
    "Nombre de la moneda",
    "Abreviatura",
    "Tipo de cambio a BRT",
    "Acciones",
    "Actualizar",
    "Eliminar",
    "¿Eliminar moneda?",
    "Gestión de usuarios",
    "Nombre",
    "Moneda",
    "Saldo",
    "Deuda",
    "Rol",
    "Estado",
    "Acción",
    "Usuario",
    "Administrador",
    "Bloqueado",
    "Activo",
    "Bloqueado",
    "Suspendido",
    "Editar",
    "¿Eliminar usuario?",
    "Gestión del sistema",
    "Descargar al ordenador",
    "Descargar Users.bin",
    "Descargar Transactions.bin",
    "Borrar datos",
    "Borrar usuarios",
    "Borrar transacciones",
    "Resetear monedas",
    "¡ADVERTENCIA: Esto eliminará todos los usuarios!",
    "¡ADVERTENCIA: Esto eliminará todas las transacciones!",
    "¡ADVERTENCIA: Esto reseteará las monedas a valores predeterminados!",
    "Importar datos (reemplazar actual)",
    "Subir Users.bin",
    "Subir Transactions.bin",
    "Subir Currencies.bin",
    "¿Reemplazar TODOS los usuarios del archivo?",
    "¿Reemplazar TODAS las transacciones del archivo?",
    "¿Reemplazar TODAS las monedas del archivo?",
    "Información del sistema",
    "Usuarios",
    "Transacciones",
    "Monedas",
    "Memoria libre",
    "Tiempo de funcionamiento",
    "Almacenamiento",
    "Transacciones",
    "Sesiones activas",
    "Lista de sesiones",
    "Historial de transacciones",
    "Sin transacciones",
    "Hora",
    "De",
    "A",
    "Cantidad",
    "Moneda",
    "Tipo de cambio",
    "Hash",
    "Última visualización",
    "Panel de administración",
    "Panel de administración",
    "Monedas",
    "Usuarios",
    "Sistema",
    "Panel de control",
    "Cuenta personal",
    "Mis datos",
    "ID",
    "Saldo",
    "Calificación",
    "Moneda",
    "Transferencia de dinero",
    "-- Seleccionar destinatario --",
    "Cantidad",
    "Pagar",
    "Panel de admin",
    "Inicio",
    "Cerrar sesión",
    "Inicio de sesión MBB",
    "Sistema bancario MBB",
    "Nombre de usuario",
    "Contraseña",
    "Iniciar sesión",
    "Crear nueva cuenta",
    "Versión",
    "Sistema financiero",
    "Registro",
    "Recordarme",
    "¡Error de inicio de sesión!",
    "¡Registro exitoso!",
    "¡Error de registro!",
    "Pago completado",
    "¡Batería baja!",
    "Conecta el cargador",
    "¡Voltaje crítico de batería! Guardando datos...",
    "Monitoreo de batería desactivado (alimentación USB)",
    "Advertencia: Batería baja",
    "Batería OK",
    "Advertencia de alimentación"
};    
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < 100; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файловой системы (если файл существует)
    loadTextsFromFS();
}

// Загрузка текстов из файловой системы (опционально)
void loadTextsFromFS() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        return;
    }
    
    int index = 0;
    while (file.available() && index < 100) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        if (line.length() > 0 && !line.startsWith("#")) {
            if (index < textCount) {
                labels[index] = line;
            }
            index++;
        }
    }
    
    file.close();
    
    if (index > 0 && index < textCount) {
        textCount = index;
    }
    
    Serial.println("Loaded " + String(index) + " texts from file system");
}

// Создание файла с текстами в файловой системе (для редактирования)
void createTextsFile() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    for (int i = 0; i < textCount; i++) {
        file.println(labels[i]);
    }
    
    file.close();
    Serial.println("Created texts file with " + String(textCount) + " entries");
}
