#include <WiFi.h>
#include <WebServer.h>
#include <SPIFFS.h>
#include <ArduinoJson.h>
#include <time.h>
// Конфигурация WiFi
const char* ssid = "AnnonceBoard_1.0.2";
const char* password = "";

WebServer server(80);

// HTML страница прямо в коде
const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MBS-Movable Bartik Storage</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:Arial,sans-serif;background:#f0f0f0;padding:20px;}
.container{max-width:800px;margin:0 auto;background:white;border-radius:10px;padding:20px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
h1{text-align:center;margin-bottom:20px;color:#333;}
.search-box{margin-bottom:20px;position:relative;}
.search-box input{width:100%;padding:10px 40px 10px 10px;border:1px solid #ddd;border-radius:5px;font-size:14px;}
.search-icon{position:absolute;right:10px;top:50%;transform:translateY(-50%);color:#666;}
form{display:flex;flex-direction:column;gap:10px;margin-bottom:20px;}
input,textarea,select{padding:10px;border:1px solid #ddd;border-radius:5px;font-size:14px;}
button{padding:10px;background:#007bff;color:white;border:none;border-radius:5px;cursor:pointer;}
button:hover{background:#0056b3;}
.ad-card{border:1px solid #ddd;border-radius:5px;padding:15px;margin-bottom:10px;}
.ad-header{display:flex;justify-content:space-between;margin-bottom:10px;}
.ad-title{font-weight:bold;font-size:18px;}
.ad-category{background:#28a745;color:white;padding:2px 8px;border-radius:10px;font-size:12px;}
.delete-btn{background:#dc3545;padding:5px 10px;font-size:12px;}
.delete-btn:hover{background:#c82333;}
.no-ads{text-align:center;color:#666;padding:20px;}
.search-results{margin-bottom:10px;color:#666;font-size:14px;}
</style>
</head>
<body>
<div class="container">
    <h1>📋 MBS </h1>
    <h3>Movable Bartik Storage</h3>
    <div class="search-box">
        <input type="text" id="search-input" placeholder="🔍 Search">
        <div class="search-icon">🔍</div>
    </div>
    <div class="search-results" id="search-results">All products</div>
    
    <div class="new-ad">
        <h2>Add new</h2>
        <form id="ad-form">
            <input type="text" id="title" placeholder="Title" required>
            <textarea id="content" placeholder="Text annonce" rows="3" required></textarea>
            <select id="category" required>
                <option value="">Select category</option>
                <option value="sale">Sale</option>
                <option value="buy">Buy</option>
                <option value="service">Service</option>
                <option value="job">Job</option>
                <option value="other">Other</option>
            </select>
            <button type="submit">Public</button>
        </form>
    </div>

    <div class="ads-list">
        <h2>Annonces</h2>
        <div id="ads-container"></div>
    </div>
</div>

<script>
class BoardApp {
    constructor() { 
        this.ads = [];
        this.filteredAds = [];
        this.init(); 
    }
    
    async init() {
        await this.loadAds();
        this.setupEventListeners();
        setInterval(() => this.loadAds(), 5000);
    }

    setupEventListeners() {
        // Поиск
        document.getElementById('search-input').addEventListener('input', (e) => {
            this.filterAds(e.target.value);
        });
        
        // Добавление объявления
        document.getElementById('ad-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addAd();
        });
    }

    async loadAds() {
        try {
            const response = await fetch('/ads');
            this.ads = await response.json();
            this.filterAds(document.getElementById('search-input').value);
        } catch (error) {
            console.error('Error:', error);
        }
    }

    filterAds(searchText) {
        searchText = searchText.toLowerCase().trim();
        
        if (searchText === '') {
            this.filteredAds = [...this.ads];
            document.getElementById('search-results').textContent = `All annonces (${this.filteredAds.length})`;
        } else {
            this.filteredAds = this.ads.filter(ad => 
                ad.title.toLowerCase().includes(searchText) ||
                ad.content.toLowerCase().includes(searchText) ||
                ad.category.toLowerCase().includes(searchText)
            );
            document.getElementById('search-results').textContent = 
                `Find: ${this.filteredAds.length} by requiest "${searchText}"`;
        }
        
        this.renderAds(this.filteredAds);
    }

    renderAds(adsToRender) {
        const container = document.getElementById('ads-container');
        container.innerHTML = '';
        
        if (adsToRender.length === 0) {
            const searchText = document.getElementById('search-input').value;
            if (searchText) {
                container.innerHTML = '<div class="no-ads">Nothing found with your request</div>';
            } else {
                container.innerHTML = '<div class="no-ads">Annonce no at a moment</div>';
            }
            return;
        }
        
        // Сортируем по времени (новые сначала)
        const sortedAds = [...adsToRender].sort((a, b) => b.timestamp - a.timestamp);
        
        sortedAds.forEach(ad => {
            const adElement = document.createElement('div');
            adElement.className = 'ad-card';
            adElement.innerHTML = `
                <div class="ad-header">
                    <div class="ad-title">${this.escapeHtml(ad.title)}</div>
                    <span class="ad-category">${this.escapeHtml(ad.category)}</span>
                </div>
                <div>${this.escapeHtml(ad.content)}</div>
                <div style="margin-top:10px;font-size:12px;color:#666;">
                    ID: ${ad.id}
                    <button class="delete-btn" onclick="app.deleteAd(${ad.id})" style="float:right">Delete</button>
                </div>
            `;
            container.appendChild(adElement);
        });
    }

    async addAd() {
        const title = document.getElementById('title').value;
        const content = document.getElementById('content').value;
        const category = document.getElementById('category').value;

        const formData = new FormData();
        formData.append('title', title);
        formData.append('content', content);
        formData.append('category', category);

        try {
            const response = await fetch('/post', { method: 'POST', body: formData });
            const result = await response.json();
            
            if (result.status === 'success') {
                document.getElementById('ad-form').reset();
                await this.loadAds();
                
                // Очищаем поиск после добавления нового объявления
                document.getElementById('search-input').value = '';
                this.filterAds('');
                
            } else {
                alert('Error: ' + result.message);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error add the annonce');
        }
    }

    async deleteAd(id) {
        if (!confirm('Delete this annonce?')) return;
        
        const formData = new FormData();
        formData.append('id', id);
        
        try {
            const response = await fetch('/delete', { method: 'POST', body: formData });
            const result = await response.json();
            
            if (result.status === 'success') {
                await this.loadAds();
                
                // Обновляем поиск после удаления
                const searchText = document.getElementById('search-input').value;
                this.filterAds(searchText);
                
            } else {
                alert('Error: ' + result.message);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error delete annonce');
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

const app = new BoardApp();
</script>
</body></html>
)rawliteral";

// Структура для объявлений
struct Advertisement {
  String timeString; // "12:30 25.12.2025"
  uint32_t id;
  String title;
  String content;
  String category;
  uint32_t timestamp;
};

const int MAX_ADS = 50;
Advertisement ads[MAX_ADS];
int adCount = 0;
uint32_t nextId = 1;

// Прототипы функций
void handleRoot();
void handlePostAd();
void handleGetAds();
void handleDeleteAd();
void saveData();
void loadData();
void check_room();

void setup() {
  Serial.begin(115200);
  
  // Инициализация SPIFFS
  if (!SPIFFS.begin(true)) {
    Serial.println("Error initialisation SPIFFS");
    return;
  }
  
  // Настройка WiFi
  WiFi.softAP(ssid, password);
  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);
  
  // Загрузка данных
  loadData();
  
  // Настройка маршрутов сервера
  server.on("/", HTTP_GET, handleRoot);
  server.on("/post", HTTP_POST, handlePostAd);
  server.on("/ads", HTTP_GET, handleGetAds);
  server.on("/delete", HTTP_POST, handleDeleteAd);
  
  server.begin();
  Serial.println("HTTP sercer started");
}

void loop() {
  server.handleClient();
}

// Обработчик главной страницы
void handleRoot() {
  server.send(200, "text/html", INDEX_HTML);
}

// Обработчик добавления объявления
void handlePostAd() {
  if (server.hasArg("title") && server.hasArg("content") && server.hasArg("category")) {
        String title = server.arg("title");
        String content = server.arg("content");
        
        if (title.length() > 100) {
            server.send(400, "application/json", "{\"status\":\"error\",\"message\":\"Much long title\"}");
            return;
        }
        if (content.length() > 500) {
            server.send(400, "application/json", "{\"status\":\"error\",\"message\":\"Much long annonce\"}");
            return;
        }
    
    
    if (adCount < MAX_ADS) {
      ads[adCount].id = nextId++;
      ads[adCount].title = server.arg("title");
      ads[adCount].content = server.arg("content");
      ads[adCount].category = server.arg("category");
      ads[adCount].timestamp = millis();
      
      adCount++;
      saveData();
      
      server.send(200, "application/json", "{\"status\":\"success\",\"id\":" + String(ads[adCount-1].id) + "}");
    } else {
      server.send(507, "application/json", "{\"status\":\"error\",\"message\":\"Reach the limit of annonces\"}");
    }
  } else {
    server.send(400, "application/json", "{\"status\":\"error\",\"message\":\"Fill please all fields\"}");
  }
}

// Обработчик получения объявлений
void handleGetAds() {
  DynamicJsonDocument doc(4096);
  JsonArray array = doc.to<JsonArray>();
  
  for (int i = 0; i < adCount; i++) {
    JsonObject obj = array.createNestedObject();
    obj["id"] = ads[i].id;
    obj["title"] = ads[i].title;
    obj["content"] = ads[i].content;
    obj["category"] = ads[i].category;
    obj["timestamp"] = ads[i].timestamp;
  }
  
  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

// Обработчик удаления объявления
void handleDeleteAd() {
  if (server.hasArg("id")) {
    uint32_t id = server.arg("id").toInt();
    bool found = false;
    
    for (int i = 0; i < adCount; i++) {
      if (ads[i].id == id) {
        // Сдвигаем массив
        for (int j = i; j < adCount - 1; j++) {
          ads[j] = ads[j + 1];
        }
        adCount--;
        found = true;
        saveData();
        break;
      }
    }
    
    if (found) {
      server.send(200, "application/json", "{\"status\":\"success\"}");
    } else {
      server.send(404, "application/json", "{\"status\":\"error\",\"message\":\"Annonce not found\"}");
    }
  } else {
    server.send(400, "application/json", "{\"status\":\"error\",\"message\":\"ID not entered\"}");
  }
}

// Сохранение данных в SPIFFS
void saveData() {
  File file = SPIFFS.open("/data.json", "w");
  if (!file) {
    Serial.println("Error of open file for write");
    return;
  }
  
  DynamicJsonDocument doc(4096);
  doc["nextId"] = nextId;
  JsonArray array = doc.createNestedArray("ads");
  
  for (int i = 0; i < adCount; i++) {
    JsonObject obj = array.createNestedObject();
    obj["id"] = ads[i].id;
    obj["title"] = ads[i].title;
    obj["content"] = ads[i].content;
    obj["category"] = ads[i].category;
    obj["timestamp"] = ads[i].timestamp;
  }
  
  serializeJson(doc, file);
  file.close();
  Serial.println("Data was safe");
}

// Загрузка данных из SPIFFS
void loadData() {
  if (SPIFFS.exists("/data.json")) {
    File file = SPIFFS.open("/data.json", "r");
    if (!file) {
      Serial.println("Error open data file");
      return;
    }
    
    DynamicJsonDocument doc(4096);
    DeserializationError error = deserializeJson(doc, file);
    file.close();
    
    if (error) {
      Serial.println("Error of reading data file");
      return;
    }
    
    nextId = doc["nextId"];
    JsonArray array = doc["ads"];
    adCount = array.size();
    
    for (int i = 0; i < adCount; i++) {
      ads[i].id = array[i]["id"];
      ads[i].title = array[i]["title"].as<String>();
      ads[i].content = array[i]["content"].as<String>();
      ads[i].category = array[i]["category"].as<String>();
      ads[i].timestamp = array[i]["timestamp"];
    }
    
    Serial.println("Data uploaded: Annonces count: " + String(adCount));
  } else {
    Serial.println("Data file not found. Will start from zero");
  }
}

void cleanupOldAds() {
    const uint32_t MAX_AGE = 7 * 24 * 60 * 60 * 1000; // 7 дней
    uint32_t currentTime = millis();
    
    for (int i = 0; i < adCount; i++) {
        if (currentTime - ads[i].timestamp > MAX_AGE) {
            // Удаляем старое объявление
            for (int j = i; j < adCount - 1; j++) {
                ads[j] = ads[j + 1];
            }
            adCount--;
            i--; // Проверяем текущий индекс again
        }
    }
    saveData();
}

// Ограничение длины объявления
void handlePostAd2() {
    if (server.hasArg("title") && server.hasArg("content")) {
        String title = server.arg("title");
        String content = server.arg("content");
        
        if (title.length() > 100) {
            server.send(400, "application/json", "{\"status\":\"error\",\"message\":\"Much long title\"}");
            return;
        }
        if (content.length() > 500) {
            server.send(400, "application/json", "{\"status\":\"error\",\"message\":\"Much long annonce\"}");
            return;
        }
        // ... остальной код
    }
}

// добавляем дату создания объявления
// В структуру добавить




// При создании объявления
void updateTimeString(Advertisement &ad) {
    time_t now = time(nullptr);
    struct tm* timeinfo = localtime(&now);
    char buffer[20];
    strftime(buffer, sizeof(buffer), "%H:%M %d.%m.%Y", timeinfo);
    ad.timeString = String(buffer);
}
//проверка свободного места в SPIFFS
void check_room(){
  Serial.printf("Total space: %d bytes\n", SPIFFS.totalBytes());
Serial.printf("Used space: %d bytes\n", SPIFFS.usedBytes());
  }
  
