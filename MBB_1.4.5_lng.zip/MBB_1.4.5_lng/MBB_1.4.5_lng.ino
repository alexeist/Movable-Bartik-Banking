
/* Movable Bartik Banking server
 *  This software are shared under MIT license. Please use this OpenSourse soft according MIT license
 *  Version 1.3.4 - SD Card support & Mobile optimization
*/


/* Movable Bartik Banking server  */
const char* ver = "1.4.4_en_debt";  

/*Debugging*/
bool debug = true;

/* What's new in 1.3.3:
 * 1. Поддержка SD-карты для неограниченного хранения данных
 * 2. Увеличенные лимиты пользователей и транзакций
 * 3. Оптимизация HTML для мобильных устройств
 * 4. Автоматическая миграция данных с SPIFFS на SD-карту
 * 5. Улучшенное управление памятью
*/

#include <Arduino.h>
#include <ArduinoOTA.h>
#include <WebSocketsServer.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <WiFi.h>
#include <SPIFFS.h>
#include <SD.h>
#include <SPI.h>
#include <driver/gpio.h>  // Для C3 gpio_wakeup_enable
#include "esp_sleep.h"
#include "soc/rtc.h"
#include <pgmspace.h>
//include "text.cpp"

// Конфигурация SD-карты
//#define SD_CS 5
// Измените определение пина CS в начале кода:
#define SD_CS 5  //  GPIO 5

#define SPI_SPEED 1000000  // Уменьшите скорость до 1 MHz если есть проблемы
//#define SPI_SPEED 4000000

// Файлы на SD-карте
const char* sdUsersFilename = "/MBB/users.bin";
const char* sdTransactionsFilename = "/MBB/transactions.bin"; 
const char* sdCurrenciesFilename = "/MBB/currencies.bin";

// Файлы в SPIFFS (для обратной совместимости)
const char* usersFilename = "/users.bin";
const char* transactionsFilename = "/transactions.bin";
const char* currenciesFilename = "/currencies.bin";

//настройка wakeup and sleep

#define WAKEUP_GPIO_ESP32 GPIO_NUM_13  // Безопасный пин для WROOM
#define WAKEUP_GPIO_C3 GPIO_NUM_2     // Безопасный пин для C3
#define DEEP_SLEEP_TIMEOUT 5 * 60 * 1000  // 5 минут в миллисекундах

#ifndef LED_BUILTIN
#define LED_BUILTIN 2
#endif

#define AP_SSID "Bartik3"
#define AP_PASSWORD ""
#define OTA_PASSWORD ""
/*
#define MAX_USERS 200           // Увеличено с 20
#define MAX_USERS_ONLINE 20     // Увеличено с 10
#define MAX_TRANSACTIONS 2000   // Увеличено с 500
#define MAX_CURRENCIES 20       // Увеличено с 10
*/

// УМЕНЬШЕННЫЕ РАЗМЕРЫ ДЛЯ ЭКОНОМИИ RAM
#define MAX_USERS 200           // ↓ было 200
#define MAX_USERS_ONLINE 5    // ↓ было 20  
#define MAX_TRANSACTIONS 900   // ↓ было 2000
#define MAX_CURRENCIES 4      // ↓ было 20



static unsigned long  lastPrint  = 0;

enum UserRole { ROLE_USER = 0, ROLE_ADMIN = 1, ROLE_BLOCKED = 2};
enum UserState { STATE_ACTIVE = 0, STATE_BLOCKED = 1, STATE_SUSPENDED = 2, STATE_BANKROUT = 3 };

struct User {
  char username[16];
  char password[16];
  unsigned long registrationTime;
  char currency[8];
  float balance;
  float debt;
  uint8_t rating;
  uint8_t state;
  UserRole role;
};

struct Currency {
  char name[15];
  char abbr[4];
  float rate;  // курс к BRT (базовой валюте)
};

struct Transaction {
  unsigned long timestamp;
  char fromUser[16];
  char toUser[16];
  float amount;
  char currency[8];
  char blockchain[11];
  float exchangeRate; // курс на момент транзакции
};

// Структура для хранения сессий
struct Session {
  char sessionId[33];
  char username[32];
  unsigned long expiryTime;
};


unsigned long lastActivityTime   = 0;
unsigned long lastActivityCheck  = 0;
bool   hasActivity               = false; 
bool isAuthenticated             = false;
String currentUser               = "";         // последний активный пользователь, онлайн может быть несколько

UserRole currentUserRole         = ROLE_USER;  // По умолчанию USER, не BLOCKED
bool sdCardAvailable             = false;      // Флаг доступности SD-карты

AsyncWebServer server(80);
WebSocketsServer webSocket = WebSocketsServer(81); // WebSocket на порту 81

// Структура для хранения подключенных клиентов
struct ConnectedClient {
  String username;
  bool authenticated;
};
ConnectedClient connectedClients[10]; // Максимум 10 подключений

bool ledState = false;
unsigned long startTime = 0;

User users[MAX_USERS];
int userCount = 0;

// Таймер только для пользовательских действий
unsigned long lastUserActionTime = 0;

Transaction transactions[MAX_TRANSACTIONS];
int transactionCount = 0;

Currency currencies[MAX_CURRENCIES];
int currencyCount = 3;

// Система сессий
Session sessions[10]; // Максимум 10 активных сессий
const char* sessionCookieName = "ESP32_BARTIK_SESSION";
const unsigned long SESSION_DURATION =  30 * 60 * 1000; // 30 min

// Массивы букв для генерации псевдонима
const char consonants[] = "bcdfghjklmnpqrstvwxyz";
const char vowels[] = "aeiou";
const int CONSONANTS_COUNT = 21;
const int VOWELS_COUNT = 5;

// Прототипы функций
void setupAuth();
bool registerUser(String username, String password, String currency = "BRT");
bool loginUser(String username, String password);
bool userExists(String username);
void saveUsersToFile();
void loadUsersFromFile();
String hashPassword(String password);
void logoutUser();
User* getUserByUsername(String username);
bool makePayment(String fromUser, String toUser, float amount, String currency);
void saveTransactionsToFile();
void loadTransactionsFromFile();
String generateBlockchainHash(Transaction* transaction, String previousHash = "");
String getDashboardHTML(String username);
void loadCurrenciesFromFile();
void saveCurrenciesToFile();
void initializeDefaultCurrencies();
float convertCurrency(float amount, String fromCurrency, String toCurrency);
String getAdminPanelHTML();
String getCurrencyManagementHTML();
String getUserManagementHTML();
String getSystemManagementHTML();
void debugUsers();
void resetUsersFile();
void checkTransactionLimit();  // Проверка и сигнализация лимита транзакций
void handleExportAndResetUsers(AsyncWebServerRequest *request);
void handleExportAndResetTransactions(AsyncWebServerRequest *request);
void handleExportAndResetCurrencies(AsyncWebServerRequest *request);

// Функции для работы с SD-картой
bool initSDCard();
bool migrateDataToSD();
bool fileExists(const char* filename);
File openFileForRead(const char* filename);
File openFileForWrite(const char* filename);

// WebSocket функции
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length);
void notifyUser(String username, String message);
void sendToUser(String username, String message);
void setupWebSocket();
void notifyPaymentReceived(String toUser, String fromUser, float amount, String currency);

// Функции для работы с SD-картой
bool initSDCard() {
  Serial.println("Initializing SD card...");
  
  // Настройка SPI с явным указанием пинов
  SPI.begin(18, 19, 23, SD_CS);  // SCK, MISO, MOSI, CS
  
  if (!SD.begin(SD_CS, SPI, SPI_SPEED)) {
    Serial.println("SD Card initialization failed!");
    Serial.println("Trying alternative initialization...");
    
    // Альтернативная попытка инициализации
    if (!SD.begin(SD_CS)) {
      Serial.println("SD Card initialization completely failed!");
      return false;
    }
  }
  
  // Проверка типа карты
uint8_t  cardType = CARD_NONE;
   cardType = SD.cardType();
  if (cardType == CARD_NONE) {
    Serial.println("No SD card attached");
    return false;
  }
  
  Serial.print("SD Card Type: ");
  if (cardType == CARD_MMC) {
    Serial.println("MMC");
  } else if (cardType == CARD_SD) {
    Serial.println("SDSC");
  } else if (cardType == CARD_SDHC) {
    Serial.println("SDHC");
  } else {
    Serial.println("UNKNOWN");
  }
  
  uint64_t cardSize = SD.cardSize() / (1024 * 1024);
  uint64_t usedSpace = SD.usedBytes() / (1024 * 1024);
  Serial.printf("SD Card Size: %lluMB\n", cardSize);
  Serial.printf("Used Space: %lluMB\n", usedSpace);
  Serial.printf("Free Space: %lluMB\n", cardSize - usedSpace);
  
  return true;
}

void updateUserActivity() {
  lastUserActionTime = millis();
}

bool migrateDataToSD() {
  Serial.println("Starting data migration to SD card...");
  bool success = true;
  
  // Миграция пользователей
  if (SPIFFS.exists(usersFilename)) {
    File spiffsFile = SPIFFS.open(usersFilename, "r");
    File sdFile = SD.open(sdUsersFilename, "w");
    if (spiffsFile && sdFile) {
      size_t fileSize = spiffsFile.size();
      uint8_t buffer[256];
      size_t bytesRead;
      
      while ((bytesRead = spiffsFile.read(buffer, sizeof(buffer))) > 0) {
        sdFile.write(buffer, bytesRead);
      }
      
      spiffsFile.close();
      sdFile.close();
      Serial.printf("Users migrated to SD card (%d bytes)\n", fileSize);
    } else {
      Serial.println("Failed to migrate users");
      success = false;
    }
  }
  
  // Миграция транзакций
  if (SPIFFS.exists(transactionsFilename)) {
    File spiffsFile = SPIFFS.open(transactionsFilename, "r");
    File sdFile = SD.open(sdTransactionsFilename, "w");
    if (spiffsFile && sdFile) {
      size_t fileSize = spiffsFile.size();
      uint8_t buffer[256];
      size_t bytesRead;
      
      while ((bytesRead = spiffsFile.read(buffer, sizeof(buffer))) > 0) {
        sdFile.write(buffer, bytesRead);
      }
      
      spiffsFile.close();
      sdFile.close();
      Serial.printf("Transactions migrated to SD card (%d bytes)\n", fileSize);
    } else {
      Serial.println("Failed to migrate transactions");
      success = false;
    }
  }
  
  // Миграция валют
  if (SPIFFS.exists(currenciesFilename)) {
    File spiffsFile = SPIFFS.open(currenciesFilename, "r");
    File sdFile = SD.open(sdCurrenciesFilename, "w");
    if (spiffsFile && sdFile) {
      size_t fileSize = spiffsFile.size();
      uint8_t buffer[256];
      size_t bytesRead;
      
      while ((bytesRead = spiffsFile.read(buffer, sizeof(buffer))) > 0) {
        sdFile.write(buffer, bytesRead);
      }
      
      spiffsFile.close();
      sdFile.close();
      Serial.printf("Currencies migrated to SD card (%d bytes)\n", fileSize);
    } else {
      Serial.println("Failed to migrate currencies");
      success = false;
    }
  }
  
  if (success) {
    Serial.println("Data migration completed successfully");
  } else {
    Serial.println("Data migration completed with errors");
  }
  
  return success;
}

bool fileExists(const char* filename) {
  if (sdCardAvailable) {
    return SD.exists(filename);
  } else {
    return SPIFFS.exists(filename);
  }
}

File openFileForRead(const char* filename) {
  if (sdCardAvailable) {
    return SD.open(filename, "r");
  } else {
    return SPIFFS.open(filename, "r");
  }
}

File openFileForWrite(const char* filename) {
  if (sdCardAvailable) {
    return SD.open(filename, "w");
  } else {
    return SPIFFS.open(filename, "w");
  }
}
/////////////////////////////

// Функции для работы с сессиями
String generateSessionId() {
  String sessionId = "";
  for (int i = 0; i < 32; i++) {
    int randomValue = random(0, 16);
    sessionId += String(randomValue, HEX);
  }
  return sessionId;
}

Session* findSession(String sessionId) {
  for (int i = 0; i < 10; i++) {
    if (String(sessions[i].sessionId) == sessionId && millis() < sessions[i].expiryTime) {
      return &sessions[i];
    }
  }
  return nullptr;
}

String createSession(String username) {
  // Удаляем просроченные сессии
  for (int i = 0; i < 10; i++) {
    if (millis() >= sessions[i].expiryTime) {
      memset(&sessions[i], 0, sizeof(Session));
    }
  }

  // Ищем свободный слот
  for (int i = 0; i < 10; i++) {
    if (sessions[i].expiryTime == 0 || millis() >= sessions[i].expiryTime) {
      String newSessionId = generateSessionId();
      strncpy(sessions[i].sessionId, newSessionId.c_str(), sizeof(sessions[i].sessionId) - 1);
      strncpy(sessions[i].username, username.c_str(), sizeof(sessions[i].username) - 1);
      sessions[i].expiryTime = millis() + SESSION_DURATION;

//      Serial.println("New sessins is created: " + username + " (ID: " + newSessionId.substring(0, 8) + "...)");
      return newSessionId;
    }
  }
  Serial.println("No free slots for user session: " + username);
  return ""; // Нет свободных слотов
}

void deleteSession(String sessionId) {
  for (int i = 0; i < 10; i++) {
    if (String(sessions[i].sessionId) == sessionId) {
      Serial.println("Deleted session for: " + String(sessions[i].username));
      memset(&sessions[i], 0, sizeof(Session));
      break;
    }
  }
}

int getActiveSessionsCount() {
  int count = 0;
  for (int i = 0; i < 10; i++) {
    if (sessions[i].expiryTime > 0 && millis() < sessions[i].expiryTime) {
      count++;
    }
  }
  return count;
}


String getCookieValue(AsyncWebServerRequest *request, String cookieName) {
  if (request->hasHeader("Cookie")) {
    String cookie = request->getHeader("Cookie")->value();
    int start = cookie.indexOf(cookieName + "=");
    if (start != -1) {
      start += cookieName.length() + 1;
      int end = cookie.indexOf(";", start);
      if (end == -1) end = cookie.length();
      return cookie.substring(start, end);
    }
  }
  return "";
}


bool checkAuth(AsyncWebServerRequest *request) {
  String sessionId = getCookieValue(request, sessionCookieName);
  if (sessionId != "") {
    Session* session = findSession(sessionId);
    if (session) {
      currentUser = String(session->username);
      User* user = getUserByUsername(currentUser);
      if (user) {
        currentUserRole = user->role;
        isAuthenticated = true;
        updateActivityTime();  // Добавь: активность при запросе!
        // Обновляем время expiry сессии
        session->expiryTime = millis() + SESSION_DURATION;
        return true;
      }
    }
  }
  isAuthenticated = false;
  currentUser = "";
  currentUserRole = ROLE_USER;
  return false;
}




void handleExportAndResetUsers(AsyncWebServerRequest *request) {
  if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
    request->redirect("/");
    return;
  }

  // Шаг 1: Логируем
  Serial.println("Admin " + currentUser + " initiated export+purge of users");

  // Для этого хэндлера: возвращаем HTML с авто-скачиванием и редиректом на очистку.
  String html = "<!DOCTYPE html><html><head><title>Export...</title></head><body>";
  html += "<script>";
  html += "setTimeout(function() {";
  html += "  window.location.href = '/export-users?download=1';";  // Скачиваем
  html += "  setTimeout(function() {";
  html += "    fetch('/resetUsers', {method: 'POST'}).then(() => {";
  html += "      alert('Export complete, data cleared!');";
  html += "      window.location.href = '/admin';";
  html += "    });";
  html += "  }, 5000);";  // 5 сек на скачивание
  html += "}, 500);";
  html += "</script>";
  html += "<p>Exporting... Please wait.</p></body></html>";

  request->send(200, "text/html", html);
}



void handleExportAndResetTransactions(AsyncWebServerRequest *request) {
  if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
    request->redirect("/");
    return;
  }

  Serial.println("Admin " + currentUser + " initiated export+purge transactions");

  String html = "<!DOCTYPE html><html><head><title>Экспорт...</title></head><body>";
  html += "<script>";
  html += "setTimeout(function() {";
  html += "  window.location.href = '/export-transactions?download=1';";
  html += "  setTimeout(function() {";
  html += "    fetch('/resetTransactions', {method: 'POST'}).then(() => {";
  html += "      alert('Export complete, transactions cleared!');";
  html += "      window.location.href = '/admin';";
  html += "    });";
  html += "  }, 2000);";
  html += "}, 500);";
  html += "</script>";
  html += "<p>Exporting transactions... Please wait.</p></body></html>";

  request->send(200, "text/html", html);
}

// Функция для обновления времени активности
void updateActivityTime() {
  lastActivityTime = millis();
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  // Инициализация генератора случайных чисел для сессий
  randomSeed(micros());

  Serial.println("Initialization ...");
  Serial.println("MBB Version: " + String(ver));

  // Инициализация SPIFFS
  if (!SPIFFS.begin(true)) {
    Serial.println("error SPIFFS");
    return;
  }

  // Инициализация текстов
    initTexts();
    
  //настройкa wakeup:
  // Настрой wake-up (fallback на таймер 5 мин)
  esp_sleep_enable_timer_wakeup(DEEP_SLEEP_TIMEOUT * 1000ULL);  // us, не ms!
 
  // Проверяем причину пробуждения при старте
  esp_sleep_wakeup_cause_t wakeup_reason = esp_sleep_get_wakeup_cause();

#if CONFIG_IDF_TARGET_ESP32C3 || CONFIG_IDF_TARGET_ESP32S3 || CONFIG_IDF_TARGET_ESP32S2
  // Для ESP32-C3, S3, S2 (без EXT0)
  gpio_wakeup_enable(WAKEUP_GPIO_C3, GPIO_INTR_HIGH_LEVEL);
  esp_sleep_enable_gpio_wakeup();
  Serial.println("Using GPIO wakeup for ESP32-C3/S3/S2");
#else
  // Для ESP32, ESP32-WROOM (с EXT0)
  esp_sleep_enable_ext0_wakeup(WAKEUP_GPIO_ESP32, 1);
  Serial.println("Using EXT0 wakeup for ESP32/WROOM");
#endif

  if (wakeup_reason == ESP_SLEEP_WAKEUP_TIMER) {
    Serial.println("Woke up from timer");
  } else if (wakeup_reason == ESP_SLEEP_WAKEUP_UNDEFINED) {
    Serial.println("Cold boot");
    updateActivityTime();
  } else {
    Serial.printf("Woke up from: %d\n", wakeup_reason);
    updateActivityTime();
  }  

//  Serial.println("\n=== SD Card Diagnostic ===");
//  Serial.printf("SD_CS Pin: %d\n", SD_CS);
//  Serial.printf("SPI Pins - SCK:18, MISO:19, MOSI:23\n");
  
  // Проверка пинов
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH); // Деактивировать SD карту по умолчанию
  if(debug){
    Serial.print("main 580. Use SD CS pin ");
    Serial.println(SD_CS);
    }
  // Проверка напряжения
//  float voltage = 3.3; // ESP32 работает на 3.3V
//  Serial.printf("Operating voltage: %.1fV\n", voltage);  
  
  // Инициализация SD-карты
    SPI.begin(18, 19, 23, SD_CS);  // SCK, MISO, MOSI, CS
  sdCardAvailable = initSDCard();
  
  if (sdCardAvailable) {
    Serial.println("Using SD card for data storage");
    // Миграция данных при первом запуске
    if (!SD.exists(sdUsersFilename) && (SPIFFS.exists(usersFilename) || SPIFFS.exists(transactionsFilename))) {
      migrateDataToSD();
    }
  } else {
    Serial.println("Using SPIFFS for data storage");
  }

  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, HIGH);
 
  lastActivityTime = millis(); // Инициализация времени активности

  // Загружаем данные
  loadCurrenciesFromFile();
  loadUsersFromFile();
  loadTransactionsFromFile();

  // Если проснулся по таймеру — коротко проверь и спи дальше
  if (wakeup_reason == ESP_SLEEP_WAKEUP_TIMER) {
    // Быстрая проверка: есть ли клиенты? Если да — active
    if (WiFi.softAPgetStationNum() > 0) {
      updateActivityTime();
      Serial.println("Clients detected on timer wake — staying active!");
    } else {
      Serial.println("No clients — back to sleep soon.");
      // Можно сразу sleep, но дай время на loop
    }
  }

  // Перезапусти WiFi/server только если нужно (e.g. по GPIO или если был sleep)
//  if (wakeup_reason != ESP_SLEEP_WAKEUP_UNDEFINED) {
    Serial.println("Create an access point...");

    if (!WiFi.softAP(AP_SSID, AP_PASSWORD)) {
      Serial.println("Access point creation error!");
      return;
    }

    IPAddress myIP = WiFi.softAPIP();
    Serial.println("=======================================");
    Serial.println("        ESP32 Finance Server Ready");
    Serial.println("=======================================");
    Serial.printf("SSID: %s\n", AP_SSID);
    Serial.printf("Password: %s\n", AP_PASSWORD);
    Serial.printf("IP address: %s\n", myIP.toString().c_str());
    Serial.println("Version: " + String(ver));
    Serial.println("Storage: " + String(sdCardAvailable ? "SD Card" : "SPIFFS"));
    Serial.println("=======================================");

    startTime = millis();
    setupAuth();
    
    server.begin();
    Serial.println("HTTP server started at port 80");
    Serial.println("http://" + WiFi.softAPIP().toString());

    // ДОБАВЛЯЕМ ИНИЦИАЛИЗАЦИЮ WEB SOCKET
    setupWebSocket();
    
    // OTA часть (обязательно!)
    ArduinoOTA.setPassword(OTA_PASSWORD); // Тот же пароль!
    ArduinoOTA.onStart([]() {
      Serial.println("OTA update started...");
    });
    ArduinoOTA.onEnd([]() {
      Serial.println("OTA update finished!");
    });

    ArduinoOTA.begin();
  
}

void loop() {
  // Проверяем сессии каждые 30 сек (чтобы не спамить)
  if (millis() - lastActivityCheck > 30000) {
    lastActivityCheck = millis();
    
    // Проверяем текущую сессию (если есть)
    if (isAuthenticated && !currentUser.isEmpty()) {
      bool sessionValid = false;
      for (int i = 0; i < 10; i++) {
        if (String(sessions[i].username) == currentUser && millis() < sessions[i].expiryTime) {
          sessionValid = true;
          // Продлеваем сессию
          sessions[i].expiryTime = millis() + SESSION_DURATION;
          break;
        }
      }
      if (!sessionValid) {
        isAuthenticated = false;
        currentUser = "";
        currentUserRole = ROLE_USER;
        Serial.println("Session expired: logged out globally.");
      }
    }
  }

  // Обновляем активность ТОЛЬКО при реальной активности
  if (webSocket.connectedClients() > 0) {
    updateActivityTime();
  }

  // Проверка таймаута для глубокого сна
    if (lastUserActionTime > 0 && (millis() - lastUserActionTime) > DEEP_SLEEP_TIMEOUT) {
    // ... вход в глубокий сон ...
    Serial.println("No activity for 5 minutes. Entering deep sleep...");

    // Сохраняем данные
    saveUsersToFile();
    saveTransactionsToFile();
    saveCurrenciesToFile();

    // Очищаем сессии и WS перед сном
    for (int i = 0; i < 10; i++) {
      memset(&sessions[i], 0, sizeof(Session));
    }
    webSocket.disconnect();  // Закрой все WS
    webSocket.close();

    // Отключаем всё
    server.end();
    WiFi.disconnect(true);
    WiFi.mode(WIFI_OFF);

    delay(1000);  // Дай время на cleanup

    // Deep sleep

    esp_deep_sleep_start();
  }

  // Принт статуса (теперь lastPrint работает правильно)
  if (millis() - lastPrint > 30000) {
    lastPrint = millis();
    String authStatus = isAuthenticated ?
                        "Authenticated (" + currentUser + ", " + (currentUserRole == ROLE_ADMIN ? "Admin" : "User") + ")" :
                        "Not authenticated";
    unsigned long inactiveTime = lastActivityTime > 0 ? (millis() - lastActivityTime) / 1000 : 0;
    Serial.printf("[%lu сек] Memory: %d bytes, Status: %s, Inactive: %lu sec, Active sessions: %d, Storage: %s\n",
                  millis() / 1000, ESP.getFreeHeap(), authStatus.c_str(), inactiveTime, getActiveSessionsCount(),
                  sdCardAvailable ? "SD Card" : "SPIFFS");
  }

  webSocket.loop();
  ArduinoOTA.handle();
  delay(100);
}
