// texts_data.ino - Текстовые данные для веб-интерфейса
 
// Функция инициализации текстов (значения по умолчанию)
void initTexts() {
const char* defaultTexts[] = {
    "Gestione valute",
    "Aggiungi nuova valuta",
    "Nome valuta",
    "Abbreviazione (3 caratteri)",
    "Tasso di cambio verso BRT",
    "Aggiungi valuta",
    "Valute attuali",
    "Nome valuta",
    "Abbreviazione",
    "Tasso di cambio verso BRT",
    "Azioni",
    "Aggiorna",
    "Elimina",
    "Eliminare valuta?",
    "Gestione utenti",
    "Nome",
    "Valuta",
    "Saldo",
    "Debito",
    "Ruolo",
    "Stato",
    "Azione",
    "Utente",
    "Amministratore",
    "Bloccato",
    "Attivo",
    "Bloccato",
    "Sospeso",
    "Modifica",
    "Eliminare utente?",
    "Gestione sistema",
    "Scarica su computer",
    "Scarica Users.bin",
    "Scarica Transactions.bin",
    "Cancella dati",
    "Cancella utenti",
    "Cancella transazioni",
    "Resetta valute",
    "ATTENZIONE: Questo eliminerà tutti gli utenti!",
    "ATTENZIONE: Questo eliminerà tutte le transazioni!",
    "ATTENZIONE: Questo resetterà le valute ai valori predefiniti!",
    "Importa dati (sostituisci attuali)",
    "Carica Users.bin",
    "Carica Transactions.bin",
    "Carica Currencies.bin",
    "Sostituire TUTTI gli utenti dal file?",
    "Sostituire TUTTE le transazioni dal file?",
    "Sostituire TUTTE le valute dal file?",
    "Informazioni di sistema",
    "Utenti",
    "Transazioni",
    "Valute",
    "Memoria libera",
    "Tempo di funzionamento",
    "Archiviazione",
    "Transazioni",
    "Sessioni attive",
    "Elenco sessioni",
    "Cronologia transazioni",
    "Nessuna transazione",
    "Ora",
    "Da",
    "A",
    "Importo",
    "Valuta",
    "Tasso",
    "Hash",
    "Ultima visualizzazione",
    "Pannello di amministrazione",
    "Pannello di amministrazione",
    "Valute",
    "Utenti",
    "Sistema",
    "Pannello di controllo",
    "Account personale",
    "I miei dati",
    "ID",
    "Saldo",
    "Valutazione",
    "Valuta",
    "Trasferimento denaro",
    "-- Seleziona destinatario --",
    "Importo",
    "Paga",
    "Pannello admin",
    "Home",
    "Esci",
    "Accesso MBB",
    "Sistema bancario MBB",
    "Nome utente",
    "Password",
    "Accedi",
    "Crea nuovo account",
    "Versione",
    "Sistema finanziario",
    "Registrazione",
    "Ricordami",
    "Errore di accesso!",
    "Registrazione riuscita!",
    "Errore di registrazione!",
    "Pagamento completato",
    "Batteria bassa!",
    "Collega il caricabatterie",
    "Tensione batteria critica! Salvataggio dati...",
    "Monitoraggio batteria disattivato (alimentazione USB)",
    "Avviso: Batteria bassa",
    "Batteria OK",
    "Avviso alimentazione"
};    
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < 100; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файловой системы (если файл существует)
    loadTextsFromFS();
}

// Загрузка текстов из файловой системы (опционально)
void loadTextsFromFS() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        return;
    }
    
    int index = 0;
    while (file.available() && index < 100) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        if (line.length() > 0 && !line.startsWith("#")) {
            if (index < textCount) {
                labels[index] = line;
            }
            index++;
        }
    }
    
    file.close();
    
    if (index > 0 && index < textCount) {
        textCount = index;
    }
    
    Serial.println("Loaded " + String(index) + " texts from file system");
}

// Создание файла с текстами в файловой системе (для редактирования)
void createTextsFile() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    for (int i = 0; i < textCount; i++) {
        file.println(labels[i]);
    }
    
    file.close();
    Serial.println("Created texts file with " + String(textCount) + " entries");
}
