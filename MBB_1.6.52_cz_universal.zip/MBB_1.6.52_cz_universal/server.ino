
void setupAuth() {

  // Инициализация случайного генератора для сессий
  randomSeed(micros());

  server.on("/", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (checkAuth(request)) {
      request->redirect("/dashboard");
      return;
    }

    String html = "<!DOCTYPE HTML><html><head><title>Financial system</title><meta charset=\"UTF-8\">";
    html += "<style>body{font-family:Arial;text-align:center;margin:50px;background:#f5f5f5;}";
    html += ".container{background:white;padding:30px;border-radius:15px;max-width:400px;margin:0 auto;}";
    html += ".tabs{display:flex;margin-bottom:20px;}";
    html += ".tab{flex:1;padding:10px;cursor:pointer;border:1px solid #ddd;}";
    html += ".tab.active{background:#3498db;color:white;}";
    html += ".form{display:none;}";
    html += ".form.active{display:block;}";
    html += "input,select{width:100%;padding:10px;margin:5px 0;box-sizing:border-box;}";
    html += "button{width:100%;padding:10px;background:#3498db;color:white;border:none;border-radius:5px;cursor:pointer;}";
    html += "</style></head><body>";
    html += "<div class=\"container\"><h2>MBB Financial system v. " + String(ver) + "</h2>";
    html += "<div class=\"tabs\">";
    
    html += "<div class=\"tab active\" onclick=\"showTab('login')\">Login</div>";
    
    html += "<div class=\"tab\" onclick=\"showTab('register')\">Register</div>";
    html += "</div>";

    html += "<form id=\"loginForm\" class=\"form active\" action=\"/login\" method=\"POST\">";
    html += "<input type=\"text\" name=\"username\" placeholder=\"User name\" required>";
    html += "<input type=\"password\" name=\"password\" placeholder=\"Password\" required>";
    html += "<label style=\"text-align:left;display:block;\"><input type=\"checkbox\" name=\"remember\" checked> Remember me</label>";
    html += "<button type=\"submit\">Login</button>";
    html += "</form>";
    
    html += "<form id=\"registerForm\" class=\"form\" action=\"/register\" method=\"POST\">";
    html += "<input type=\"text\" name=\"username\" placeholder=\"User name\" required>";
    html += "<input type=\"password\" name=\"password\" placeholder=\"Password\" required>";
    html += "<select name=\"currency\">";

    for (int i = 0; i < currencyCount; i++) {
      html += "<option value=\"" + String(currencies[i].abbr) + "\">" + String(currencies[i].abbr) + " - " + String(currencies[i].name) + "</option>";
    }

    html += "</select>";
    html += "<button type=\"submit\">Register</button>";
    html += "</form></div>";
    html += "<script>";
    html += "function showTab(tabName){";
    html += "document.querySelectorAll('.tab').forEach(tab=>tab.classList.remove('active'));";
    html += "document.querySelectorAll('.form').forEach(form=>form.classList.remove('active'));";
    html += "document.querySelector('.tab:nth-child('+(tabName==='login'?1:2)+')').classList.add('active');";
    html += "document.getElementById(tabName+'Form').classList.add('active');}";
    html += "</script></body></html>";

    request->send(200, "text/html; charset=utf-8", html);
  });

  server.on("/login", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    String username = request->arg("username");
    String password = request->arg("password");
    bool remember = request->hasArg("remember");

    if (loginUser(username, password)) {
      String sessionId = createSession(username);
      if (sessionId != "") {
        AsyncWebServerResponse *response = request->beginResponse(302, "text/plain", "Redirecting...");
        String cookie = String(sessionCookieName) + "=" + sessionId + "; Path=/; HttpOnly";
        if (remember) {
          cookie += "; Max-Age=86400"; // 24 часа
        }
        response->addHeader("Location", "/dashboard");
        response->addHeader("Set-Cookie", cookie);
        request->send(response);

        //        Serial.println("Session created for user: " + username + " (Remember: " + String(remember ? "Yes" : "No") + ")");
      } else {
        request->send(200, "text/html", "<script>alert('Error creating session!'); window.location='/';</script>");
      }
    } else {
      request->send(200, "text/html", "<script>alert('Login error!'); window.location='/';</script>");
    }
  });

  server.on("/register", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    String username = request->arg("username");
    String password = request->arg("password");
    String currency = request->arg("currency");

    if (registerUser(username, password, currency)) {
      request->send(200, "text/html", "<script>alert('Successful register !'); window.location='/';</script>");
    } else {
      request->send(200, "text/html", "<script>alert('Error register!'); window.location='/';</script>");
    }
  });

  server.on("/dashboard", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request)) {
      request->redirect("/");
      return;
    }
    request->send(200, "text/html; charset=utf-8", getDashboardHTML(currentUser));
  });

  server.on("/admin", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }
    request->send(200, "text/html; charset=utf-8", getAdminPanelHTML());
  });

server.on("/payment", HTTP_POST, [](AsyncWebServerRequest *request) {
  updateUserActivity();
  if (!checkAuth(request)) {
    request->redirect("/");
    return;
  }

  String toUser = request->arg("toUser");
  float amount = request->arg("amount").toFloat();
  String currency = request->arg("currency");

  String paymentResult = makePayment(currentUser, toUser, amount, currency);

  if (paymentResult.startsWith("Payment completed")) {
    String redirectPath = (currentUserRole == 1) ? "/admin" :
                          (currentUserRole == 0) ? "/dashboard" : "/";
    request->send(
      200,
      "text/html",
      "<script>alert('" + paymentResult + "'); "
      "window.location='" + redirectPath + "';</script>"
    );
  } else {
    request->send(
      200,
      "text/html",
      "<script>alert('Payment Error: " + paymentResult + "'); "
      "window.location='/';</script>"
    );
  }
});

// Административные endpoints
  server.on("/addCurrency", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    String name = request->arg("name");
    String abbr = request->arg("abbr");
    float rate = request->arg("rate").toFloat();

    if (currencyCount >= MAX_CURRENCIES) {
      request->send(200, "text/html", "<script>alert('Currency limit reached!'); window.location='/admin';</script>");
      return;
    }

    strcpy(currencies[currencyCount].name, name.c_str());
    strcpy(currencies[currencyCount].abbr, abbr.c_str());
    currencies[currencyCount].rate = rate;
    currencyCount++;

    saveCurrenciesToFile();
    request->send(200, "text/html", "<script>alert('Currency added!'); window.location='/admin';</script>");
  });

  server.on("/updateCurrency", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    int index = request->arg("index").toInt();
    float rate = request->arg("rate").toFloat();

    if (index >= 0 && index < currencyCount) {
      currencies[index].rate = rate;
      saveCurrenciesToFile();
      request->send(200, "text/html", "<script>alert('Rate updated!'); window.location='/admin';</script>");
    } else {
      request->send(200, "text/html", "<script>alert('Error update!'); window.location='/admin';</script>");
    }
  });

  server.on("/deleteCurrency", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    int index = request->arg("index").toInt();

    if (index >= 0 && index < currencyCount && String(currencies[index].abbr) != "BRT") {
      // Сдвигаем валюты
      for (int i = index; i < currencyCount - 1; i++) {
        currencies[i] = currencies[i + 1];
      }
      currencyCount--;
      saveCurrenciesToFile();
      request->send(200, "text/html", "<script>alert('Currency removed!'); window.location='/admin';</script>");
    } else {
      request->send(200, "text/html", "<script>alert('Base currency cannot be deleted BRT!'); window.location='/admin';</script>");
    }
  });

  server.on("/updateUserRole", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    String username = request->arg("username");
    UserRole role = (UserRole)request->arg("role").toInt();

    User* user = getUserByUsername(username);
    if (user) {
      user->role = role;
      saveUsersToFile();
      request->send(200, "text/html", "<script>alert('Role updated!'); window.location='/admin';</script>");
    } else {
      request->send(200, "text/html", "<script>alert('User not found!'); window.location='/admin';</script>");
    }
  });

  server.on("/updateUserState", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    String username = request->arg("username");
    UserState state = (UserState)request->arg("state").toInt();

    User* user = getUserByUsername(username);
    if (user) {
      user->state = state;
      saveUsersToFile();
      request->send(200, "text/html", "<script>alert('Status updated!'); window.location='/admin';</script>");
    } else {
      request->send(200, "text/html", "<script>alert('User not found!'); window.location='/admin';</script>");
    }
  });

  server.on("/deleteUser", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    String username = request->arg("username");

    for (int i = 0; i < userCount; i++) {
      if (String(users[i].username) == username) {
        // Сдвигаем пользователей
        for (int j = i; j < userCount - 1; j++) {
          users[j] = users[j + 1];
        }
        userCount--;
        saveUsersToFile();
        request->send(200, "text/html", "<script>alert('User removed!'); window.location='/admin';</script>");
        return;
      }
    }
    request->send(200, "text/html", "<script>alert('User not found!'); window.location='/admin';</script>");
  });

  server.on("/resetUsers", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    userCount = 0;
    saveUsersToFile();
    request->send(200, "text/html", "<script>alert('Users cleared!'); window.location='/admin';</script>");
  });

  server.on("/resetTransactions", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    transactionCount = 0;
    saveTransactionsToFile();
    request->send(200, "text/html", "<script>alert('Transactions cleared!'); window.location='/admin';</script>");
  });

  server.on("/resetCurrencies", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    initializeDefaultCurrencies();
    request->send(200, "text/html", "<script>alert('Currencies reset!'); window.location='/admin';</script>");
  });

  server.on("/logout", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    String sessionId = getCookieValue(request, sessionCookieName);
    if (sessionId != "") {
      deleteSession(sessionId);
    }

    AsyncWebServerResponse *response = request->beginResponse(302, "text/plain", "Redirecting...");
    response->addHeader("Location", "/");
    response->addHeader("Set-Cookie", String(sessionCookieName) + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
    request->send(response);

    logoutUser();
    Serial.println("User logged off (session deleted)");
  });

  // Endpoint для отладки сессий (только для админов)
  server.on("/debug-sessions", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    String html = "<!DOCTYPE HTML><html><head><title>Debugging sessions</title><meta charset=\"UTF-8\"></head><body>";
    html += "<h2>Active sessinos</h2><table border='1'><tr><th>Session ID</th><th>Username</th><th>Expires In</th></tr>";

    for (int i = 0; i < 10; i++) {
      if (sessions[i].expiryTime > 0 && millis() < sessions[i].expiryTime) {
        html += "<tr>";
        html += "<td>" + String(sessions[i].sessionId).substring(0, 16) + "...</td>";
        html += "<td>" + String(sessions[i].username) + "</td>";
        html += "<td>" + String((sessions[i].expiryTime - millis()) / 1000) + " sec</td>";
        html += "</tr>";
      }
    }

    html += "</table><br><a href=\"/admin\">Go to admin panel</a></body></html>";
    request->send(200, "text/html", html);
  });

  // Экспорт users.bin для админа
  server.on("/export-users", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    File file = SPIFFS.open(usersFilename, "r");
    if (!file) {
      request->send(404, "text/plain", "File not found");
      return;
    }

    // Используем прямой метод отправки
    request->send(file, usersFilename, "application/octet-stream");
    file.close();

    Serial.println("Admin " + currentUser + " downloades users.bin (" + String(file.size()) + " Bytes)");
  });

  // Экспорт transactions.bin для админа
  server.on("/export-transactions", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    File file = SPIFFS.open(transactionsFilename, "r");
    if (!file) {
      request->send(404, "text/plain", "File not found");
      return;
    }

    // Используем прямой метод отправки
    request->send(file, transactionsFilename, "application/octet-stream");
    file.close();

    file.close();

    Serial.println("Admin " + currentUser + " downloads transactions.bin (" + String(file.size()) + " Bytes)");
  });

  // Экспорт currencies.bin для админа
  server.on("/export-currencies", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->redirect("/");
      return;
    }

    File file = SPIFFS.open(currenciesFilename, "r");
    if (!file) {
      request->send(404, "text/plain", "File not found");
      return;
    }

    // Используем прямой метод отправки
    request->send(file, currenciesFilename, "application/octet-stream");
    file.close();

    file.close();

    Serial.println("Admin " + currentUser + " downloads currencies.bin (" + String(file.size()) + " Bytes)");
  });

  // === ЗАГРУЗКА ФАЙЛОВ (ИМПОРТ) ===
  server.on("/upload-users", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->requestAuthentication();
      return;
    }
    request->send(200, "text/html", "<h3>Uploading users.bin...</h3><script>setTimeout(()=>{location.href='/admin'}, 3000);</script>");
  }, [](AsyncWebServerRequest * request, String filename, size_t index, uint8_t *data, size_t len, bool final) {
    static File f;
    const char* target = sdCardAvailable ? sdUsersFilename : usersFilename;

    if (!index) {
      Serial.printf("UploadStart: %s → %s\n", filename.c_str(), target);
      f = openFileForWrite(target);
      userCount = 0; // полностью заменяем
    }
    if (f) f.write(data, len);
    if (final) {
      if (f) f.close();
      loadUsersFromFile(); // перезагружаем в RAM
      Serial.printf("UploadEnd: %s (%u bytes)\n", target, index + len);
    }
  });

  server.on("/upload-transactions", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->requestAuthentication();
      return;
    }
    request->send(200, "text/html", "<h3>Uploading transactions.bin...</h3><script>setTimeout(()=>{location.href='/admin'}, 3000);</script>");
  }, [](AsyncWebServerRequest * request, String filename, size_t index, uint8_t *data, size_t len, bool final) {
    static File f;
    const char* target = sdCardAvailable ? sdTransactionsFilename : transactionsFilename;

    if (!index) {
      Serial.printf("UploadStart: %s → %s\n", filename.c_str(), target);
      f = openFileForWrite(target);
      transactionCount = 0;
    }
    if (f) f.write(data, len);
    if (final) {
      if (f) f.close();
      loadTransactionsFromFile();
      Serial.printf("UploadEnd: %s (%u bytes)\n", target, index + len);
    }
  });

  server.on("/upload-currencies", HTTP_POST, [](AsyncWebServerRequest * request) {
    updateUserActivity();
    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->requestAuthentication();
      return;
    }
    request->send(200, "text/html", "<h3>Uploading currencies.bin...</h3><script>setTimeout(()=>{location.href='/admin'}, 3000);</script>");
  }, [](AsyncWebServerRequest * request, String filename, size_t index, uint8_t *data, size_t len, bool final) {
    static File f;
    const char* target = sdCardAvailable ? sdCurrenciesFilename : currenciesFilename;

    if (!index) {
      Serial.printf("UploadStart: %s → %s\n", filename.c_str(), target);
      f = openFileForWrite(target);
      currencyCount = 0;
    }
    if (f) f.write(data, len);
    if (final) {
      if (f) f.close();
      loadCurrenciesFromFile();
      initializeDefaultCurrencies(); // на случай, если файл пустой
      Serial.printf("UploadEnd: %s (%u bytes)\n", target, index + len);
    }
  });

  // === ДЕБУГ ИНФОРМАЦИЯ ДЛЯ АДМИНА ===
  server.on("/debug", HTTP_GET, [](AsyncWebServerRequest * request) {
    updateUserActivity();

    if (!checkAuth(request) || currentUserRole != ROLE_ADMIN) {
      request->send(401, "text/plain", "Unauthorized");
      return;
    }

    // Собираем информацию
    String debugInfo = "";
    debugInfo += "=== MBB DEBUG INFO ===\n";
    debugInfo += "Version: " + String(ver) + "\n";
    debugInfo += "Uptime: " + String(millis() / 1000) + " seconds\n";
    debugInfo += "Current user: " + currentUser + "\n";
    debugInfo += "User role: " + String(currentUserRole == ROLE_ADMIN ? "Admin" : "User") + "\n";

    // 1. Информация о хранилище
    debugInfo += "\n--- STORAGE INFO ---\n";

    if (sdCardAvailable) {
      uint64_t cardSize = SD.cardSize();
      uint64_t totalBytes = SD.totalBytes();
      uint64_t usedBytes = SD.usedBytes();
      debugInfo += "Storage: SD Card\n";
      debugInfo += "Card size: " + String(cardSize / (1024 * 1024)) + " MB\n";
      debugInfo += "Total: " + String(totalBytes / 1024) + " KB\n";
      debugInfo += "Used: " + String(usedBytes / 1024) + " KB\n";
      debugInfo += "Free: " + String((totalBytes - usedBytes) / 1024) + " KB\n";

      // Информация о файлах на SD
      debugInfo += "\nSD Card files:\n";
      File root = SD.open("/");
      File file = root.openNextFile();
      while (file) {
        if (!file.isDirectory()) {
          debugInfo += "  " + String(file.name()) + " - " + String(file.size()) + " bytes\n";
        }
        file = root.openNextFile();
      }
      root.close();
    } else {
      size_t totalBytes = SPIFFS.totalBytes();
      size_t usedBytes = SPIFFS.usedBytes();
      debugInfo += "Storage: SPIFFS\n";
      debugInfo += "Total: " + String(totalBytes / 1024) + " KB\n";
      debugInfo += "Used: " + String(usedBytes / 1024) + " KB\n";
      debugInfo += "Free: " + String((totalBytes - usedBytes) / 1024) + " KB\n";
    }

    // 2. Время с последней активности
    debugInfo += "\n--- ACTIVITY INFO ---\n";
    if (lastActivityTime > 0) {
      unsigned long inactiveSeconds = (millis() - lastActivityTime) / 1000;
      debugInfo += "Last activity: " + String(inactiveSeconds) + " seconds ago\n";
      debugInfo += "Time to sleep: " + String((DEEP_SLEEP_TIMEOUT / 1000) - inactiveSeconds) + " seconds\n";
    } else {
      debugInfo += "Last activity: Never\n";
    }

    // 3. Системная информация
    debugInfo += "\n--- SYSTEM INFO ---\n";
    debugInfo += "Free heap: " + String(ESP.getFreeHeap()) + " bytes\n";
    debugInfo += "Min free heap: " + String(ESP.getMinFreeHeap()) + " bytes\n";
    debugInfo += "Max alloc heap: " + String(ESP.getMaxAllocHeap()) + " bytes\n";
    debugInfo += "Chip revision: " + String(ESP.getChipRevision()) + "\n";
    debugInfo += "Chip model: " + String(ESP.getChipModel()) + "\n";
    debugInfo += "CPU frequency: " + String(ESP.getCpuFreqMHz()) + " MHz\n";
    debugInfo += "Flash size: " + String(ESP.getFlashChipSize() / (1024 * 1024)) + " MB\n";

    // 4. Сетевые данные
    debugInfo += "\n--- NETWORK INFO ---\n";
    debugInfo += "AP SSID: " + String(AP_SSID) + "\n";
    debugInfo += "AP IP: " + WiFi.softAPIP().toString() + "\n";
    debugInfo += "Connected stations: " + String(WiFi.softAPgetStationNum()) + "\n";
    debugInfo += "WebSocket clients: " + String(webSocket.connectedClients()) + "\n";

    // 5. Данные приложения
    debugInfo += "\n--- APPLICATION DATA ---\n";
    debugInfo += "Users: " + String(userCount) + " / " + String(MAX_USERS) + "\n";
    debugInfo += "Transactions: " + String(transactionCount) + " / " + String(MAX_TRANSACTIONS) + "\n";
    debugInfo += "Currencies: " + String(currencyCount) + " / " + String(MAX_CURRENCIES) + "\n";
    debugInfo += "Active sessions: " + String(getActiveSessionsCount()) + "\n";
    debugInfo += "Authenticated: " + String(isAuthenticated ? "Yes" : "No") + "\n";

    // 6. Информация о файлах данных
    debugInfo += "\n--- DATA FILES ---\n";
    if (sdCardAvailable) {
      debugInfo += "users.bin: " + (SD.exists(sdUsersFilename) ? String(SD.open(sdUsersFilename, FILE_READ).size()) + " bytes" : "Not found") + "\n";
      debugInfo += "transactions.bin: " + (SD.exists(sdTransactionsFilename) ? String(SD.open(sdTransactionsFilename, FILE_READ).size()) + " bytes" : "Not found") + "\n";
      debugInfo += "currencies.bin: " + (SD.exists(sdCurrenciesFilename) ? String(SD.open(sdCurrenciesFilename, FILE_READ).size()) + " bytes" : "Not found") + "\n";
    } else {
      debugInfo += "users.bin: " + (SPIFFS.exists(usersFilename) ? String(SPIFFS.open(usersFilename, FILE_READ).size()) + " bytes" : "Not found") + "\n";
      debugInfo += "transactions.bin: " + (SPIFFS.exists(transactionsFilename) ? String(SPIFFS.open(transactionsFilename, FILE_READ).size()) + " bytes" : "Not found") + "\n";
      debugInfo += "currencies.bin: " + (SPIFFS.exists(currenciesFilename) ? String(SPIFFS.open(currenciesFilename, FILE_READ).size()) + " bytes" : "Not found") + "\n";
    }

    // 7. Время и сон
    debugInfo += "\n--- SLEEP INFO ---\n";
    debugInfo += "Sleep timeout: " + String(DEEP_SLEEP_TIMEOUT / 1000) + " seconds\n";
    debugInfo += "Wakeup reason: ";
    esp_sleep_wakeup_cause_t wakeup_reason = esp_sleep_get_wakeup_cause();
    switch (wakeup_reason) {
      case ESP_SLEEP_WAKEUP_EXT0: debugInfo += "EXT0 (GPIO)\n"; break;
      case ESP_SLEEP_WAKEUP_EXT1: debugInfo += "EXT1\n"; break;
      case ESP_SLEEP_WAKEUP_TIMER: debugInfo += "Timer\n"; break;
      case ESP_SLEEP_WAKEUP_TOUCHPAD: debugInfo += "Touchpad\n"; break;
      case ESP_SLEEP_WAKEUP_ULP: debugInfo += "ULP\n"; break;
      //    case ESP_SLEEP_WAKEUP_PIN: debugInfo += "GPIO\n"; break;
      case ESP_SLEEP_WAKEUP_UART: debugInfo += "UART\n"; break;
      case ESP_SLEEP_WAKEUP_WIFI: debugInfo += "WiFi\n"; break;
      case ESP_SLEEP_WAKEUP_COCPU: debugInfo += "CoCPU\n"; break;
      case ESP_SLEEP_WAKEUP_COCPU_TRAP_TRIG: debugInfo += "CoCPU trap\n"; break;
      case ESP_SLEEP_WAKEUP_UNDEFINED: debugInfo += "Cold boot\n"; break;
      default: debugInfo += String(wakeup_reason) + " (unknown)\n";
    }

    debugInfo += LINE1;
    debugInfo += "\n";

    request->send(200, "text/plain", debugInfo);
  });

  ////////-----------------------------
  Serial.println("The financial system is configured with cookie, export/import and blockchain security support");
}
