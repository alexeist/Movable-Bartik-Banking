/*
MicroSD Card Adapter → ESP32 WROOM 38 пинов
-------------------------------------------
CS   (Chip Select)  → GPIO 5 (или другой свободный пин)
SCK  (Serial Clock) → GPIO 18
MOSI (Master Out)   → GPIO 23
MISO (Master In)    → GPIO 19
VCC                 → 3.3V
GND                 → GND


 SD-карта — самый важный пункт!На C3/S3 нельзя использовать стандартный SPI на любых пинах — только HSPI/VSPI или FSPI с фиксированными пинами.Рабочие варианты для C3 и S3:Модуль
ESP32-C3
CS      SCK       MISO     MOSI     Примечание           
GPIO 7  GPIO 6   GPIO 5    GPIO 4   Только эти пины!

ESP32-S3
CS      SCK       MISO     MOSI     Примечание           
GPIO 10 GPIO 12   GPIO 13  GPIO 11  Или встроенный PSRAM/SDIO
///////////////////////////


USB-TTL  ESP 32 C3
TX ---> RX (IO20)
RX ---> TX (IO21)
GND ---> GND
///////////////////////
индексация надписей
// Дополнительный файл с комментариями (texts_index.ino):

ИНДЕКСЫ ТЕКСТОВ:
0:  Currency management
1:  Add new currency
2:  Currency name
3:  Abbreviation (3 characters)
4:  Rate to BRT
5:  Add currency
6:  Current currencies
7:  Currency name (header)
8:  Abbreviation (header)
9:  Rate to BRT (header)
10: Actions
11: Update
12: Delete
13: Delete currency?
14: User management
15: Name
16: Currency
17: Amount
18: Debt
19: Role
20: Status
21: Action
22: User
23: Administrator
24: Blocked
25: Active
26: Blocked
27: Suspended
28: Change
29: Delete user?
30: System management
...


*/
