// texts_data.ino - Текстовые данные для веб-интерфейса
 
// Функция инициализации текстов (значения по умолчанию)
void initTexts() {
const char* defaultTexts[] = {
    "Gestion des devises",
    "Ajouter une nouvelle devise",
    "Nom de la devise",
    "Abréviation (3 caractères)",
    "Taux de change vers BRT",
    "Ajouter devise",
    "Devises actuelles",
    "Nom de la devise",
    "Abréviation",
    "Taux de change vers BRT",
    "Actions",
    "Mettre à jour",
    "Supprimer",
    "Supprimer la devise ?",
    "Gestion des utilisateurs",
    "Nom",
    "Devise",
    "Solde",
    "Dette",
    "Rôle",
    "Statut",
    "Action",
    "Utilisateur",
    "Administrateur",
    "Bloqué",
    "Actif",
    "Bloqué",
    "Suspendu",
    "Modifier",
    "Supprimer l'utilisateur ?",
    "Gestion du système",
    "Télécharger sur ordinateur",
    "Télécharger Users.bin",
    "Télécharger Transactions.bin",
    "Effacer les données",
    "Effacer utilisateurs",
    "Effacer transactions",
    "Réinitialiser devises",
    "ATTENTION : Cela supprimera tous les utilisateurs !",
    "ATTENTION : Cela supprimera toutes les transactions !",
    "ATTENTION : Cela réinitialisera les devises aux valeurs par défaut !",
    "Importer des données (remplacer actuel)",
    "Uploader Users.bin",
    "Uploader Transactions.bin",
    "Uploader Currencies.bin",
    "Remplacer TOUS les utilisateurs du fichier ?",
    "Remplacer TOUTES les transactions du fichier ?",
    "Remplacer TOUTES les devises du fichier ?",
    "Informations système",
    "Utilisateurs",
    "Transactions",
    "Devises",
    "Mémoire libre",
    "Temps de fonctionnement",
    "Stockage",
    "Transactions",
    "Sessions actives",
    "Liste des sessions",
    "Historique des transactions",
    "Aucune transaction",
    "Heure",
    "De",
    "À",
    "Montant",
    "Devise",
    "Taux",
    "Hash",
    "Dernier affichage",
    "Panneau d'administration",
    "Panneau d'administration",
    "Devises",
    "Utilisateurs",
    "Système",
    "Tableau de bord",
    "Compte personnel",
    "Mes données",
    "ID",
    "Solde",
    "Note",
    "Devise",
    "Transfert d'argent",
    "-- Sélectionner le destinataire --",
    "Montant",
    "Payer",
    "Panneau admin",
    "Accueil",
    "Déconnexion",
    "Connexion MBB",
    "Système bancaire MBB",
    "Nom d'utilisateur",
    "Mot de passe",
    "Se connecter",
    "Créer un nouveau compte",
    "Version",
    "Système financier",
    "Inscription",
    "Se souvenir de moi",
    "Erreur de connexion !",
    "Inscription réussie !",
    "Erreur d'inscription !",
    "Paiement terminé",
    "Batterie faible !",
    "Connectez le chargeur",
    "Tension batterie critique ! Sauvegarde des données...",
    "Surveillance batterie désactivée (alimentation USB)",
    "Avertissement : Batterie faible",
    "Batterie OK",
    "Avertissement alimentation"
};    
    textCount = sizeof(defaultTexts) / sizeof(defaultTexts[0]);
    for (int i = 0; i < textCount && i < 100; i++) {
        labels[i] = defaultTexts[i];
    }
    
    // Пытаемся загрузить из файловой системы (если файл существует)
    loadTextsFromFS();
}

// Загрузка текстов из файловой системы (опционально)
void loadTextsFromFS() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "r");
    if (!file) {
        Serial.println("Texts file not found, using defaults");
        return;
    }
    
    int index = 0;
    while (file.available() && index < 100) {
        String line = file.readStringUntil('\n');
        line.trim();
        
        if (line.length() > 0 && !line.startsWith("#")) {
            if (index < textCount) {
                labels[index] = line;
            }
            index++;
        }
    }
    
    file.close();
    
    if (index > 0 && index < textCount) {
        textCount = index;
    }
    
    Serial.println("Loaded " + String(index) + " texts from file system");
}

// Создание файла с текстами в файловой системе (для редактирования)
void createTextsFile() {
    if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
    }
    
    File file = SPIFFS.open("/data/texts.txt", "w");
    if (!file) {
        Serial.println("Failed to create texts file");
        return;
    }
    
    for (int i = 0; i < textCount; i++) {
        file.println(labels[i]);
    }
    
    file.close();
    Serial.println("Created texts file with " + String(textCount) + " entries");
}
