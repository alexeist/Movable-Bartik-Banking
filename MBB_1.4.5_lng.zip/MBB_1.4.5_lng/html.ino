
// Макрос для безопасного доступа к массиву
#define TXT(idx) (idx < textCount ? labels[idx] : "TEXT_ERROR")

// Глобальный массив для текстов
//String labels[100];
//int textCount = 0;

String getCurrencyManagementHTML() {
  const char CURRENCY_TEMPLATE[] PROGMEM = R"rawliteral(
<div class="section"><h3>{{T0}}</h3>
<h4>{{T1}}</h4>
<form action="/addCurrency" method="POST">
<input type="text" name="name" placeholder="{{T2}}" required maxlength="14">
<input type="text" name="abbr" placeholder="{{T3}}" required maxlength="3" pattern="[A-Z]{3}">
<input type="number" name="rate" step="0.000001" placeholder="{{T4}}" required>
<button type="submit">{{T5}}</button>
</form>
<h4>{{T6}}</h4><div class="table-container"><table>
<tr><th>{{T7}}</th><th>{{T8}}</th><th>{{T9}}</th><th>{{T10}}</th></tr>
{{CURRENCY_ROWS}}
</table></div></div>
)rawliteral";

  String currencyRows = "";
  for (int i = 0; i < currencyCount; i++) {
    currencyRows += "<tr>";
    currencyRows += "<td>" + String(currencies[i].name) + "</td>";
    currencyRows += "<td>" + String(currencies[i].abbr) + "</td>";
    currencyRows += "<td>" + String(currencies[i].rate, 6) + "</td>";
    currencyRows += "<td class=\"actions\">";
    currencyRows += "<form action=\"/updateCurrency\" method=\"POST\" style=\"display:inline;\">";
    currencyRows += "<input type=\"hidden\" name=\"index\" value=\"" + String(i) + "\">";
    currencyRows += "<input type=\"number\" name=\"rate\" step=\"0.000001\" value=\"" + String(currencies[i].rate, 6) + "\" class=\"small-input\">";
    currencyRows += "<button type=\"submit\">{{T11}}</button>";
    currencyRows += "</form>";
    currencyRows += "<form action=\"/deleteCurrency\" method=\"POST\" style=\"display:inline;\">";
    currencyRows += "<input type=\"hidden\" name=\"index\" value=\"" + String(i) + "\">";
    currencyRows += "<button type=\"submit\" class=\"btn-danger\" onclick=\"return confirm('{{T13}}')\">{{T12}}</button>";
    currencyRows += "</form>";
    currencyRows += "</td>";
    currencyRows += "</tr>";
  }

  // ЗДЕСЬ заменяем плейсхолдеры в currencyRows
  for (int i = 11; i <= 13; i++) {
    String placeholder = "{{T" + String(i) + "}}";
    currencyRows.replace(placeholder, TXT(i));
  }

  String html = FPSTR(CURRENCY_TEMPLATE);
  
  // Заменяем плейсхолдеры в основном шаблоне
  for (int i = 0; i <= 10; i++) {
    String placeholder = "{{T" + String(i) + "}}";
    html.replace(placeholder, TXT(i));
  }
  
  html.replace("{{CURRENCY_ROWS}}", currencyRows);
  return html;
}

String getUserManagementHTML() {
  const char USER_TEMPLATE[] PROGMEM = R"rawliteral(
<div class="section"><h3>%T14%</h3>
<div class="table-container">
<table>
<tr>
<th>%T15%</th>
<th>%T16%</th>
<th>%T17%</th>
<th>%T18%</th>
<th>%T19%</th>
<th>%T20%</th>
<th>%T21%</th>
</tr>
{{USER_ROWS}}
</table>
</div>
</div>
)rawliteral";

  String userRows = "";
  
  // Генерация строк для каждого пользователя
  for (int i = 0; i < userCount; i++) {
    String crrncy = String(users[i].currency);
    if (crrncy == "") crrncy = "BRT";
    
    userRows += "<tr>";
    userRows += "<td>" + String(users[i].username) + "</td>";
    userRows += "<td>" + crrncy + "</td>";
    userRows += "<td>" + String(users[i].balance, 2) + "</td>";
    userRows += "<td>" + String(users[i].debt, 2) + "</td>";
    
    // Роль пользователя - используем TXT() напрямую
    userRows += "<td class=\"actions\">";
    userRows += "<form action=\"/updateUserRole\" method=\"POST\" style=\"display:inline;\">";
    userRows += "<input type=\"hidden\" name=\"username\" value=\"" + String(users[i].username) + "\">";
    userRows += "<select name=\"role\" class=\"small-select\">";
    userRows += "<option value=\"0\"" + String(users[i].role == ROLE_USER ? " selected" : "") + ">";
    userRows += String(TXT(22)) + "</option>";
    userRows += "<option value=\"1\"" + String(users[i].role == ROLE_ADMIN ? " selected" : "") + ">";
    userRows += String(TXT(23)) + "</option>";
    userRows += "<option value=\"2\"" + String(users[i].role == ROLE_BLOCKED ? " selected" : "") + ">";
    userRows += String(TXT(24)) + "</option>";
    userRows += "</select>";
    userRows += "<button type=\"submit\">" + String(TXT(28)) + "</button>";
    userRows += "</form>";
    userRows += "</td>";
    
    // Статус пользователя - используем TXT() напрямую
    userRows += "<td class=\"actions\">";
    userRows += "<form action=\"/updateUserState\" method=\"POST\" style=\"display:inline;\">";
    userRows += "<input type=\"hidden\" name=\"username\" value=\"" + String(users[i].username) + "\">";
    userRows += "<select name=\"state\" class=\"small-select\">";
    userRows += "<option value=\"0\"" + String(users[i].state == STATE_ACTIVE ? " selected" : "") + ">";
    userRows += String(TXT(25)) + "</option>";
    userRows += "<option value=\"1\"" + String(users[i].state == STATE_BLOCKED ? " selected" : "") + ">";
    userRows += String(TXT(26)) + "</option>";
    userRows += "<option value=\"2\"" + String(users[i].state == STATE_SUSPENDED ? " selected" : "") + ">";
    userRows += String(TXT(27)) + "</option>";
    userRows += "</select>";
    userRows += "<button type=\"submit\">" + String(TXT(28)) + "</button>";
    userRows += "</form>";
    userRows += "</td>";
    
    // Удаление пользователя - используем TXT() напрямую
    userRows += "<td class=\"actions\">";
    userRows += "<form action=\"/deleteUser\" method=\"POST\" style=\"display:inline;\">";
    userRows += "<input type=\"hidden\" name=\"username\" value=\"" + String(users[i].username) + "\">";
    userRows += "<button type=\"submit\" class=\"btn-danger\" ";
    userRows += "onclick=\"return confirm('" + String(TXT(29)) + "')\">";
    userRows += String(TXT(12)) + "</button>";
    userRows += "</form>";
    userRows += "</td>";
    
    userRows += "</tr>";
  }
  
  // Если пользователей нет
  if (userCount == 0) {
    userRows = "<tr><td colspan=\"7\" style=\"text-align:center;\">No users found</td></tr>";
  }
  
  // Загружаем шаблон
  String html = FPSTR(USER_TEMPLATE);
  
  // Заменяем плейсхолдеры в основном шаблоне
  for (int i = 14; i <= 21; i++) {
    String placeholder = "%T" + String(i) + "%";
    html.replace(placeholder, TXT(i));
  }
  
  // Вставляем строки с пользователями
  html.replace("{{USER_ROWS}}", userRows);
  
  return html;
}

String getSystemManagementHTML() {
  const char SYSTEM_TEMPLATE[] PROGMEM = R"rawliteral(
<div class="section"><h3>%T30%</h3>

<h4>%T31%</h4>
<p><a href="/export-users"><button>%T32%</button></a>
<a href="/export-transactions"><button>%T33%</button></a></p>

<h4>%T34%</h4>
<form action="/resetUsers" method="POST" style="display:inline;">
<button type="submit" class="btn-danger" onclick="return confirm('%T38%')">%T35%</button>
</form>

<form action="/resetTransactions" method="POST" style="display:inline;">
<button type="submit" class="btn-danger" onclick="return confirm('%T39%')">%T36%</button>
</form>

<form action="/resetCurrencies" method="POST" style="display:inline;">
<button type="submit" class="btn-danger" onclick="return confirm('%T40%')">%T37%</button>
</form>

<h4>%T41%</h4>
<form method="POST" action="/upload-users" enctype="multipart/form-data">
<input type="file" name="file" accept=".bin" required>
<button type="submit" class="btn-danger" onclick="return confirm('%T45%')">%T42%</button>
</form>

<form method="POST" action="/upload-transactions" enctype="multipart/form-data">
<input type="file" name="file" accept=".bin" required>
<button type="submit" class="btn-danger" onclick="return confirm('%T46%')">%T43%</button>
</form>

<form method="POST" action="/upload-currencies" enctype="multipart/form-data">
<input type="file" name="file" accept=".bin" required>
<button type="submit" class="btn-danger" onclick="return confirm('%T47%')">%T44%</button>
</form>

<h4>%T48%</h4>
<p>%T49% : {{USER_COUNT}}</p>
<p>%T50% : {{TRANSACTION_COUNT}}</p>
<p>%T51% : {{CURRENCY_COUNT}}</p>
<p>%T52%: {{FREE_HEAP}} байт</p>
<p>%T53%: {{WORKING_TIME}} сек</p>
<p>%T54%: {{STORAGE_TYPE}}</p>
<p>%T55%: {{TRANSACTION_LIMIT}}</p>
<p>%T56%: {{ACTIVE_SESSIONS}}</p>
<a href="/debug-sessions"><button>%T57%</button></a>

<h4>%T58%</h4>
{{TRANSACTION_TABLE}}

{{LIMIT_WARNING}}
</div>
)rawliteral";

  // Генерация таблицы транзакций
  String transactionTable = "";
  if (transactionCount == 0) {
    transactionTable = "<p>" + TXT(59) + "</p>"; // No transactions
  } else {
    transactionTable += "<div class=\"table-container\">";
    transactionTable += "<table>";
    transactionTable += "<tr>";
    transactionTable += "<th>" + TXT(60) + "</th>"; // Time
    transactionTable += "<th>" + TXT(61) + "</th>"; // From
    transactionTable += "<th>" + TXT(62) + "</th>"; // To
    transactionTable += "<th>" + TXT(63) + "</th>"; // Amount
    transactionTable += "<th>" + TXT(64) + "</th>"; // Currency
    transactionTable += "<th>" + TXT(65) + "</th>"; // Rate
    transactionTable += "<th>" + TXT(66) + "</th>"; // Hash
    transactionTable += "</tr>";
    
    // Показываем последние 50 транзакций
    for (int i = transactionCount - 1; i >= max(0, transactionCount - 50); i--) {
      transactionTable += "<tr>";
      transactionTable += "<td>" + String(transactions[i].timestamp) + "</td>";
      transactionTable += "<td>" + String(transactions[i].fromUser) + "</td>";
      transactionTable += "<td>" + String(transactions[i].toUser) + "</td>";
      transactionTable += "<td>" + String(transactions[i].amount, 2) + "</td>";
      transactionTable += "<td>" + String(transactions[i].currency) + "</td>";
      transactionTable += "<td>" + String(transactions[i].exchangeRate, 6) + "</td>";
      transactionTable += "<td title=\"" + String(transactions[i].blockchain) + "\">";
      transactionTable += String(transactions[i].blockchain).substring(0, 6) + "...</td>";
      transactionTable += "</tr>";
    }
    
    transactionTable += "</table>";
    transactionTable += "</div>";
    
    // Информация о количестве отображаемых транзакций
    transactionTable += "<p><small>" + TXT(67) + " " + String(min(50, transactionCount));
    transactionTable += " transactions from " + String(transactionCount) + "</small></p>";
  }

  // Предупреждение о достижении лимита
  String limitWarning = "";
  if (transactionCount >= MAX_TRANSACTIONS) {
    limitWarning = "<div style=\"background-color:#ffcccc; padding:10px; border-left:4px solid #ff0000; margin:10px 0;\">";
    limitWarning += "<strong>ВНИМАНИЕ!</strong> Достигнут лимит транзакций (" + String(MAX_TRANSACTIONS) + "). ";
    limitWarning += "Экспортируйте данные или очистите историю транзакций.";
    limitWarning += "</div>";
  }

  // Загружаем шаблон
  String html = FPSTR(SYSTEM_TEMPLATE);
  
  // Заменяем все текстовые плейсхолдеры
  for (int i = 30; i <= 67; i++) {
    String placeholder = "%T" + String(i) + "%";
    html.replace(placeholder, TXT(i));
  }
  
  // Заменяем динамические плейсхолдеры
  html.replace("{{USER_COUNT}}", String(userCount));
  html.replace("{{TRANSACTION_COUNT}}", String(transactionCount));
  html.replace("{{CURRENCY_COUNT}}", String(currencyCount));
  html.replace("{{FREE_HEAP}}", String(ESP.getFreeHeap()));
  html.replace("{{WORKING_TIME}}", String(millis() / 1000));
  html.replace("{{STORAGE_TYPE}}", sdCardAvailable ? "SD Card" : "SPIFFS");
  
  // Информация о лимите транзакций
  html.replace("{{TRANSACTION_LIMIT}}", String(transactionCount) + "/" + String(MAX_TRANSACTIONS));
  
  // Активные сессии
  html.replace("{{ACTIVE_SESSIONS}}", String(getActiveSessionsCount()));
  
  // Таблица транзакций
  html.replace("{{TRANSACTION_TABLE}}", transactionTable);
  
  // Предупреждение о лимите
  html.replace("{{LIMIT_WARNING}}", limitWarning);
  
  return html;
}
String getAdminPanelHTML() {
  const char ADMIN_TEMPLATE[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML>
<html>
<head>
<title>%T68%</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:Arial;margin:15px;background:#f5f5f5;font-size:18px;}
.container{background:white;padding:25px;border-radius:15px;max-width:100%;margin:0 auto;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
.header{background:#dc3545;color:white;padding:25px;border-radius:10px;margin-bottom:20px;font-size:24px;}
.section{margin:20px 0;padding:20px;border:1px solid #ddd;border-radius:8px;}
.balance{font-size:28px;color:#27ae60;font-weight:bold;}
.debt{font-size:28px;color:#27ae60;font-weight:bold;}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:16px;}
th,td{padding:14px;text-align:left;border-bottom:1px solid #ddd;}
th{background-color:#f2f2f2;}
input,select{width:100%;padding:14px;margin:8px 0;box-sizing:border-box;font-size:18px;border:1px solid #ddd;border-radius:5px;}
button{padding:14px 25px;background:#3498db;color:white;border:none;border-radius:5px;cursor:pointer;margin:8px;font-size:18px;}
.btn-success{background:#28a745;}
.btn-danger{background:#dc3545;}
.admin-only{background:#fff3cd;border-left:4px solid #ffc107;padding:20px;margin:15px 0;}
.admin-nav{background:#f8f9fa;padding:18px;border-radius:8px;margin-bottom:20px;}
.admin-nav a{padding:12px 18px;margin:0 5px;background:#6c757d;color:white;text-decoration:none;border-radius:5px;font-size:16px;display:inline-block;}
.table-container{overflow-x:auto;margin:15px 0;}
.actions{white-space:nowrap;}
.small-input{width:120px;padding:8px;font-size:14px;}
.small-select{width:140px;padding:8px;font-size:14px;}
@media (max-width: 768px) {
  body{font-size:16px;margin:10px;}
  .container{padding:15px;}
  .header{padding:20px;font-size:20px;}
  input,select,button{font-size:16px;padding:12px;}
  th,td{padding:10px;font-size:14px;}
  .admin-nav a{display:block;margin:5px 0;text-align:center;}
  .small-input,.small-select{width:100px;font-size:12px;}
}
@media (max-width: 480px) {
  body{font-size:14px;margin:5px;}
  .container{padding:10px;}
  .header{padding:15px;font-size:18px;}
  th,td{padding:8px;font-size:12px;}
  button{padding:10px 15px;font-size:14px;}
}
</style>
</head>
<body>
<div class="container">
<div class="header"><h2>%T69%</h2><p>{{USER_LABEL}}: {{CURRENT_USER}} ({{ADMIN_LABEL}})</p></div>

<div class="admin-nav">
<a href="#currencies" onclick="showSection('currencies')">%T70%</a>
<a href="#users" onclick="showSection('users')">%T71%</a>
<a href="#system" onclick="showSection('system')">%T72%</a>
<a href="/dashboard">%T73%</a>
</div>

<div id="currencies-section">{{CURRENCY_SECTION}}</div>
<div id="users-section" style="display:none;">{{USER_SECTION}}</div>
<div id="system-section" style="display:none;">{{SYSTEM_SECTION}}</div>

<script>
function showSection(section){
document.getElementById('currencies-section').style.display='none';
document.getElementById('users-section').style.display='none';
document.getElementById('system-section').style.display='none';
document.getElementById(section+'-section').style.display='block';}
</script>

</div>
</body>
</html>
)rawliteral";

  // Генерируем разделы
  String currencySection = getCurrencyManagementHTML();
  String userSection = getUserManagementHTML();
  String systemSection = getSystemManagementHTML();

  // Загружаем шаблон
  String html = FPSTR(ADMIN_TEMPLATE);
  
  // Заменяем текстовые плейсхолдеры
  for (int i = 68; i <= 73; i++) {
    String placeholder = "%T" + String(i) + "%";
    html.replace(placeholder, TXT(i));
  }
  
  // Заменяем динамические плейсхолдеры
  html.replace("{{CURRENT_USER}}", currentUser);
  html.replace("{{USER_LABEL}}", TXT(15));  // "Name" или "User" из массива
  html.replace("{{ADMIN_LABEL}}", TXT(23)); // "Administrator"
  html.replace("{{CURRENCY_SECTION}}", currencySection);
  html.replace("{{USER_SECTION}}", userSection);
  html.replace("{{SYSTEM_SECTION}}", systemSection);
  
  return html;
}
String getDashboardHTML(String username) {
  User* user = getUserByUsername(username);
  if (!user) return "<p>Error: User not found</p>";
  
  bool isAdmin = (user->role == ROLE_ADMIN);
  String headerColor = isAdmin ? "#dc3545" : "#3498db";
  String headerTitle = isAdmin ? TXT(23) : TXT(74); // ADMINISTRATOR или PERSONAL_ACCOUNT
  String crrncy = (String(user->currency) == "") ? "BRT" : String(user->currency);
  
  const char DASHBOARD_TEMPLATE[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML>
<html>
<head>
<title>%T74%</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:Arial;margin:15px;background:#f5f5f5;font-size:18px;}
.container{background:white;padding:25px;border-radius:15px;max-width:100%;margin:0 auto;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
.header{background:{{HEADER_COLOR}};color:white;padding:25px;border-radius:10px;margin-bottom:20px;font-size:24px;}
.section{margin:20px 0;padding:20px;border:1px solid #ddd;border-radius:8px;}
.balance{font-size:28px;color:#27ae60;font-weight:bold;}
.debt{font-size:28px;color:#27ae60;font-weight:bold;}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:16px;}
th,td{padding:14px;text-align:left;border-bottom:1px solid #ddd;}
th{background-color:#f2f2f2;}
input,select{width:100%;padding:14px;margin:8px 0;box-sizing:border-box;font-size:18px;border:1px solid #ddd;border-radius:5px;}
button{padding:14px 25px;background:#3498db;color:white;border:none;border-radius:5px;cursor:pointer;margin:8px;font-size:18px;}
.btn-success{background:#28a745;}
.btn-danger{background:#dc3545;}
.admin-only{background:#fff3cd;border-left:4px solid #ffc107;padding:20px;margin:15px 0;}
.table-container{overflow-x:auto;margin:15px 0;}
@media (max-width: 768px) {
  body{font-size:16px;margin:10px;}
  .container{padding:15px;}
  .header{padding:20px;font-size:20px;}
  input,select,button{font-size:16px;padding:12px;}
  th,td{padding:10px;font-size:14px;}
  .balance{font-size:24px;}
  .debt{font-size:24px;}
}
@media (max-width: 480px) {
  body{font-size:14px;margin:5px;}
  .container{padding:10px;}
  .header{padding:15px;font-size:18px;}
  .section{padding:15px;}
  th,td{padding:8px;font-size:12px;}
  button{padding:10px 15px;font-size:14px;}
  .balance{font-size:20px;}
  .debt{font-size:20px;}
}
</style>
</head>
<body>
<div class="container">
<div class="header"><h2>{{HEADER_TITLE}}</h2><p>%T15%: {{USERNAME}}</p></div>

<div class="section"><h3>%T75%</h3>
<div class="table-container">
<table>
<tr><td>%T76%:</td><td><strong>{{USERNAME}}</strong></td></tr>
<tr><td>%T77%:</td><td class="balance">{{BALANCE}} {{CURRENCY}}</td></tr>
<tr><td>%T78%:</td><td>{{RATING}}/255</td></tr>
<tr><td>%T79%:</td><td>{{USER_CURRENCY}}</td></tr>
</table>
</div>
</div>

<div class="section"><h3>%T80%</h3>
<form action="/payment" method="POST">
<select name="toUser" required>
<option value="">%T81%</option>
{{USER_OPTIONS}}
</select>
<input type="number" name="amount" step="0.01" min="0.01" placeholder="%T82%" required>
<select name="currency" required>
{{CURRENCY_OPTIONS}}
</select>
<button type="submit" class="btn-success">%T83%</button>
</form>
</div>

{{ADMIN_SECTION}}

<div style="margin-top:20px;text-align:center;">
<a href="/" style="padding:10px;color:#3498db;text-decoration:none;">%T85%</a> |
<form action="/logout" method="POST" style="display:inline;">
<button type="submit" style="background:#6c757d;">%T86%</button>
</form>
</div>
</div>

<script>
var reconnectAttempts = 0;
var maxReconnectAttempts = 10;
var reconnectDelay = 2000;
var ws = null;

function connectWebSocket() {
  try {
    ws = new WebSocket('ws://' + window.location.hostname + ':81/');
    
    ws.onopen = function() {
      console.log('WebSocket connected');
      reconnectAttempts = 0;
      var sessionId = getCookie('{{SESSION_COOKIE}}');
      if(sessionId) {
        ws.send('AUTH:' + sessionId);
      }
    };
    
    ws.onmessage = function(event) {
      var message = event.data;
      console.log('WebSocket message:', message);
      
      if(message.startsWith('NOTIFICATION:')) {
        var notification = message.substring(13);
        showNotification(notification);
        playNotificationSound();
      }
      else if(message.startsWith('AUTH_SUCCESS')) {
        console.log('WebSocket authentication successful');
        localStorage.setItem('wsAuthenticated', 'true');
      }
    };
    
    ws.onclose = function() {
      console.log('WebSocket disconnected');
      if (reconnectAttempts < maxReconnectAttempts) {
        reconnectAttempts++;
        console.log('Reconnecting attempt ' + reconnectAttempts);
        setTimeout(connectWebSocket, reconnectDelay);
      } else {
        console.log('Max reconnection attempts reached');
      }
    };
    
    ws.onerror = function(error) {
      console.log('WebSocket error:', error);
    };
  } catch(error) {
    console.log('WebSocket connection error:', error);
  }
}

function playNotificationSound() {
  try {
    var audioContext = new (window.AudioContext || window.webkitAudioContext)();
    var oscillator = audioContext.createOscillator();
    var gainNode = audioContext.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch(e) {
    console.log('Audio error:', e);
    if (navigator.vibrate) navigator.vibrate(200);
  }
}

function getCookie(name) {
  var value = '; ' + document.cookie;
  var parts = value.split('; ' + name + '=');
  if (parts.length == 2) return parts.pop().split(';').shift();
  return '';
}

function showNotification(message) {
  var notification = document.createElement('div');
  notification.style.cssText = 'position:fixed; top:20px; right:20px; background:#28a745; color:white; padding:20px; border-radius:8px; z-index:1000; box-shadow:0 4px 12px rgba(0,0,0,0.3); max-width:350px; font-size:16px; line-height:1.4;';
  notification.innerHTML = '<strong>💰 New payment!</strong><br>' + message;
  document.body.appendChild(notification);
  
  setTimeout(function() {
    notification.style.opacity = '0';
    notification.style.transition = 'opacity 0.5s ease-in-out';
    setTimeout(function() {
      if(notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 500);
  }, 5000);
  
  setTimeout(function() {
    location.reload();
  }, 3000);
}

setInterval(function() {
  if(ws && ws.readyState === WebSocket.OPEN) {
    ws.send('PING');
  }
}, 30000);

document.addEventListener('DOMContentLoaded', function() {
  connectWebSocket();
});
</script>

</body>
</html>
)rawliteral";

  // Генерация опций пользователей для выбора получателя
  String userOptions = "";
  for (int i = 0; i < userCount; i++) {
    if (String(users[i].username) != username && users[i].state == STATE_ACTIVE) {
      userOptions += "<option value=\"" + String(users[i].username) + "\">";
      userOptions += String(users[i].username) + " (" + String(users[i].currency) + ")</option>";
    }
  }

  // Генерация опций валют
  String currencyOptions = "";
  for (int i = 0; i < currencyCount; i++) {
    currencyOptions += "<option value=\"" + String(currencies[i].abbr) + "\">";
    currencyOptions += String(currencies[i].abbr) + " - " + String(currencies[i].name) + "</option>";
  }

  // Генерация админ-секции
  String adminSection = "";
  if (isAdmin) {
    adminSection = "<div class=\"section admin-only\">";
    adminSection += "<h3>" + TXT(84) + "</h3>";
    adminSection += "<p>" + TXT(49) + ": " + String(userCount) + "</p>";
    adminSection += "<p>" + TXT(50) + ": " + String(transactionCount) + "</p>";
    adminSection += "<p>" + TXT(51) + ": " + String(currencyCount) + "</p>";
    adminSection += "<p>" + TXT(54) + ": " + String(sdCardAvailable ? "SD Card" : "SPIFFS") + "</p>";
    adminSection += "<a href=\"/admin\"><button class=\"btn-danger\">" + TXT(69) + "</button></a>";
    adminSection += "</div>";
  }

  // Загружаем шаблон
  String html = FPSTR(DASHBOARD_TEMPLATE);
  
  // Заменяем текстовые плейсхолдеры
  html.replace("%T74%", TXT(74));   // Personal account
  html.replace("%T15%", TXT(15));   // Name (или User)
  html.replace("%T75%", TXT(75));   // My data
  html.replace("%T76%", TXT(76));   // ID
  html.replace("%T77%", TXT(77));   // Amount
  html.replace("%T78%", TXT(78));   // Rating
  html.replace("%T79%", TXT(79));   // Currency
  html.replace("%T80%", TXT(80));   // Money transfer
  html.replace("%T81%", TXT(81));   // -- Choose a recipient --
  html.replace("%T82%", TXT(82));   // Amount (placeholder)
  html.replace("%T83%", TXT(83));   // Pay
  html.replace("%T84%", TXT(84));   // Admin panel (секция)
  html.replace("%T85%", TXT(85));   // Home
  html.replace("%T86%", TXT(86));   // Logout
  
  // Дополнительные тексты
  html.replace("%T49%", TXT(49));   // Users
  html.replace("%T50%", TXT(50));   // Transations
  html.replace("%T51%", TXT(51));   // Currencies
  html.replace("%T54%", TXT(54));   // Storage
  html.replace("%T69%", TXT(69));   // Admin panel (кнопка)
  html.replace("%T23%", TXT(23));   // Administrator (для заголовка)

  // Заменяем динамические плейсхолдеры
  html.replace("{{HEADER_COLOR}}", headerColor);
  html.replace("{{HEADER_TITLE}}", headerTitle);
  html.replace("{{USERNAME}}", username);
  html.replace("{{BALANCE}}", String(user->balance, 2));
  html.replace("{{CURRENCY}}", String(user->currency));
  html.replace("{{RATING}}", String(user->rating));
  html.replace("{{USER_CURRENCY}}", crrncy);
  html.replace("{{USER_OPTIONS}}", userOptions);
  html.replace("{{CURRENCY_OPTIONS}}", currencyOptions);
  html.replace("{{ADMIN_SECTION}}", adminSection);
  html.replace("{{SESSION_COOKIE}}", String(sessionCookieName));

  return html;
}
String getLoginHTML() {
  const char LOGIN_TEMPLATE[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html><head>
<title>T87%</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:Arial;margin:0;padding:20px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;}
.login-container{background:white;padding:40px;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3);max-width:450px;width:90%;text-align:center;}
h1{color:#333;margin-bottom:10px;font-size:32px;background:linear-gradient(90deg,#667eea,#764ba2);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.subtitle{color:#666;margin-bottom:30px;font-size:16px;}
input{width:100%;padding:18px;margin:12px 0;border:2px solid #ddd;border-radius:10px;font-size:16px;transition:border-color 0.3s;}
input:focus{border-color:#667eea;outline:none;box-shadow:0 0 0 3px rgba(102,126,234,0.1);}
button{width:100%;padding:18px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:white;border:none;border-radius:10px;font-size:18px;cursor:pointer;margin:15px 0;transition:transform 0.3s,box-shadow 0.3s;}
button:hover{transform:translateY(-2px);box-shadow:0 10px 25px rgba(102,126,234,0.3);}
.btn-register{background:linear-gradient(135deg,#28a745 0%,#20c997 100%);}
.btn-register:hover{box-shadow:0 10px 25px rgba(40,167,69,0.3);}
.version{color:#666;margin-top:20px;font-size:14px;display:flex;justify-content:space-between;}
.storage-badge{background:#f0f0f0;padding:4px 12px;border-radius:20px;font-size:12px;}

/* Адаптивность */
@media (max-width:768px){
  body{padding:10px;}
  .login-container{padding:30px 25px;}
  h1{font-size:28px;}
  input,button{padding:16px;font-size:15px;}
}

@media (max-width:480px){
  body{padding:5px;}
  .login-container{padding:25px 20px;border-radius:15px;}
  h1{font-size:24px;}
  .subtitle{font-size:14px;}
  input,button{padding:14px;font-size:14px;}
  button{font-size:16px;}
  .version{flex-direction:column;gap:5px;}
}

@media (max-height:600px) and (orientation:landscape){
  .login-container{padding:20px;margin:10px;}
  h1{margin-bottom:5px;font-size:24px;}
  .subtitle{margin-bottom:20px;}
  input{margin:8px 0;padding:14px;}
  button{margin:10px 0;padding:14px;}
}
</style></head>
<body>
<div class="login-container">
  <h1>%T88%</h1>
  <p class="subtitle">Secure banking system</p>
  
  <form action="/login" method="POST">
    <input type="text" name="username" placeholder="%T89%" required maxlength="15" autocomplete="username">
    <input type="password" name="password" placeholder="%T90%" required maxlength="15" autocomplete="current-password">
    <button type="submit">%T91%</button>
  </form>
  
  <form action="/register" method="POST">
    <button type="submit" class="btn-register">%T92%</button>
  </form>
  
  <div class="version">
    <span>%T93% {{VERSION}}</span>
    <span class="storage-badge">{{STORAGE_TYPE}}</span>
  </div>
</div>
</body></html>
)rawliteral";

  // Загружаем шаблон
  String html = FPSTR(LOGIN_TEMPLATE);
  
  // Заменяем плейсхолдеры
  html.replace("%T87%", TXT(87));   // MBB Login
  html.replace("%T88%", TXT(88));   // MBB Banking System
  html.replace("%T89%", TXT(89));   // Username
  html.replace("%T90%", TXT(90));   // Password
  html.replace("%T91%", TXT(91));   // Login
  html.replace("%T92%", TXT(92));   // Create New Account
  html.replace("%T93%", TXT(93));   // Version
  
  // Динамические данные
  html.replace("{{VERSION}}", String(ver));
  html.replace("{{STORAGE_TYPE}}", String(sdCardAvailable ? "SD Card" : "SPIFFS"));
  
  return html;
}
